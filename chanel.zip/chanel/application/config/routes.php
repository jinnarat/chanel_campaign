<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'content';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$parameter = 'A-z0-9.\- ก-ฮะาิีุูเะแำไใๆ่้๊๋ั็์ึื';

$route['content/pagecheck'] = 'content/pagecheck';
$route['content/checkcodeshop'] = 'content/checkcodeshop';
$route['precontent/pagecheck'] = 'precontent/pagecheck';
$route['precontent/checkcodeshop'] = 'precontent/checkcodeshop';
$route['content/hpage/(['.$parameter.']+)/(['.$parameter.']+)'] = 'content/hpage/$1/$2';
// $route['precontent/page/(['.$parameter.']+)/(['.$parameter.']+)'] = 'precontent/getdatahome/$1/$2';
// $route['precontent/page/2/(['.$parameter.']+)'] = 'precontent/datapage1/$3/$4';
// $route['precontent/page/3/(['.$parameter.']+)'] = 'precontent/datapage2/$1/$2';
// $route['precontent/page/4/(['.$parameter.']+)'] = 'precontent/datapage3/$1/$2';
// $route['precontent/page/5/(['.$parameter.']+)'] = 'precontent/datapage4/$1/$2';
// $route['precontent/page/6/(['.$parameter.']+)'] = 'precontent/datapage5/$1/$2';
// $route['precontent/page/7/(['.$parameter.']+)'] = 'precontent/datapage6/$1/$2';
// $route['precontent/page/8/(['.$parameter.']+)'] = 'precontent/datapage7/$1/$2';
// $route['precontent/page/9/(['.$parameter.']+)'] = 'precontent/datapage8/$1/$2';
// $route['precontent/page/10/(['.$parameter.']+)'] = 'precontent/datapage9/$1/$2';
// $route['precontent/page/11/(['.$parameter.']+)'] = 'precontent/datapage10/$1/$2';
// $route['precontent/page/12/(['.$parameter.']+)'] = 'precontent/redemption/$1/$2';
// $route['precontent/page/13/(['.$parameter.']+)'] = 'precontent/pagecheck/$1/$2';
$route['precontent/passpage'] = 'precontent/pass';
$route['precontent/nopasspage'] = 'precontent/nopass';
$route['precontent/nodatapage'] = 'precontent/nodata';

$route['(['.$parameter.']+)/(['.$parameter.']+)'] = 'content/index/$1/$2';
$route['(['.$parameter.']+)'] = 'content/content_html/$1';
$route['content/page/(:num)/(['.$parameter.']+)'] = 'content/datapage/$1/$2';
$route['precontent/page/(:num)/(['.$parameter.']+)'] = 'precontent/datapage/$1/$2';

$route['cmsadmin'] = 'cmsadmin/login';
$route['cmsadmin/login'] = 'cmsadmin/login';