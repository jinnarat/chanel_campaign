<?php
error_reporting(0);
class Content extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Content_model', 'contentdb');
        $this->load->helper('url');
    }
    public function index($cname=null, $gencode=null){
		if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
		$data['url_g']= "";
		$uri = $this->Main_function->html_chars(base_url());
        $url_gen = $this->contentdb->select_gencode("url_encode","sms_no",$gencode)->result_array();
        
        foreach($url_gen as $e)
        {
            $data['url_g'] = htmlspecialchars_decode(trim($e['url_encode']));
        }

		if(count($url_gen) > 0 ){
				$urli = str_replace("cnB","==",$data['url_g']);
				$urlnumber = base64_decode($urli);
                // $tel_no = substr($urlnumber,0,-2);
                $tel_no = substr($urlnumber,0,10);
				$campid = substr($urlnumber,10,strlen($urlnumber));
				$time = date("Y-m-d H:i:s");
				$_SESSION['tel'] = $tel_no;
				$_SESSION['campid'] = $campid;
				$this->contentdb->updatedatetostart("sms_no",$tel_no,$campid,$time,'');
				$this->getdatahome();
        }
        else
        {
			http_response_code(404);
			include('my_404.php');
			die();
		}
		
	}
 
	
 
    public function getdatahome(){

        $uri = $this->Main_function->html_chars(base_url());

        $this->load->helper('date');
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $time = date("Y-m-d H:i:s");
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];

        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['bg'] = "";
            $rs = $this->contentdb->select_data("*", "content", $campid, "1")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
        
        $this->load->view('template/header',$data);
        $this->load->view('home',$data);
        $this->load->view('template/footer');
    }

    function datapage($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['bg'] = "";

        $page = $pageno + 1;
        $data['link_page']= $uri.'content/datapage/'.$page.'/'.$campid;

        // echo 'pagenext : '.$page.'<br>pageno : '.$pageno.'<br>';
		
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            // echo count($rs);
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
					$this->load->view('template/header',$data);
		            $this->load->view('page2',$data);
		            $this->load->view('template/footer');
            }
            else{
                $this->pagecheck($campid);
            }
    }

    function pagecheck($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']= "";
        // $data['imgbut']= "";
            $rs = $this->contentdb->select_i("*", "content",$campid,11)->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
					// $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
            }
        $this->load->view('template/header');
		$this->load->view('ba_check',$data);
		$this->load->view('template/footer');
    }
	
    function checkcodeshop(){
        $uri = $this->Main_function->html_chars(base_url());
		$code = $this->input->post('code');
        $this->load->helper('date');
            if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];
        $time = date("Y-m-d H:i:s");
        $data['status'] = "";

        $rsg = $this->contentdb->select_shopcode("shop_code","store",$code)->result_array();
        // echo print_r($rsg);
        if(count($rsg)== "1"){
            $rs = $this->contentdb->select_codeshop("status","sms_no",$tel_no,$campid)->result_array();
            foreach($rs as $r){
                $data['status'] = htmlspecialchars_decode(trim($r['status']));
            }
            // echo "<br>status : ".$data['status']; 
            if($data['status'] == 'N'){
                    $this->contentdb->updatetoshopcode("sms_no",$tel_no,$campid,'Y');
                    $this->contentdb->updatetoshop_code("sms_no",$tel_no,$campid,$code);
                    $this->contentdb->updatedatetoend("sms_no",$tel_no,$campid,$time);
                    $this->pass($campid);
            }
            else {
                $this->nopass($campid); 
            }
        }
        else {
			$this->shop_warning($campid); 
        }
          
    }

    function pass($campid){

        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
        $data['detail']="";
        $data['bg'] = "";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $campid = $_SESSION['campid'];

        $rs = $this->contentdb->select_data("*", "content",$campid,"12")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
        }
        $this->load->view('template/header', $data);
		$this->load->view('passpage',$data);
		$this->load->view('template/footer');
    }
    
    function shop_warning($campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']= "";
        $data['imgbut']= "";
        $data['bg'] = "";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $campid = $_SESSION['campid'];
        $data['link_page']= $uri.'content/pagecheck/'.$campid;

        $rs = $this->contentdb->select_data("*", "content",$campid,"14")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
			$this->load->view('template/header',$data);
			$this->load->view('code_warning',$data);
			$this->load->view('template/footer');
        }
    }
	
	function checkstorecode(){
		$code = $this->input->POST('code');
		echo $code;
	}
	
	function checkcode(){
		$result = array();
		$code = $this->input->post("code");
		
		if($code){
			$result = 'pass';
		}
		
		echo json_encode($result);
		exit;
	}
	
	function nopass($campid){
		$data['img']= "";
		$data['detail']= "";
		$data['imgbut']= "";
        $data['campid']= $campid;
        $data['bg'] = "";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];
        $date = now();
        $time = date("Y-m-d H:i:s",$date);

        $data['link_page']= $uri.'content/datapage/11/'.$campid;

        if($tel_no != ''){
            $this->contentdb->insertdatetolog("log_status",$tel_no,$campid,$time,'I');
        }
            $this->contentdb->updatedatetostart("sms_no",$tel_no,$campid,$time);
            $rs = $this->contentdb->select_data("*", "content", $campid, "13")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
                    $this->load->view('template/header',$data);
		            $this->load->view('page_condition',$data);
		            $this->load->view('template/footer');
                }
            
	}
}
