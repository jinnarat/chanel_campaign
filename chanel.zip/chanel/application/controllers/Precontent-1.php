<?php
error_reporting(0);
class Precontent extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Content_model', 'contentdb');
        $this->load->helper('url');
    }
    public function index($cname=null, $gencode=null){
		
	}
    function allpage($pageno = null,$campid = null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        // $data['bg'] = "#f8f2e8";
        $data['bg'] = "";
        $data['campid']= $campid;

        $page = $pageno + 1;
        $data['link_page']= $uri.'precontent/allpage/'.$page.'/'.$campid;

        // echo 'pagenext : '.$page.'<br>pageno : '.$pageno.'<br>';
		
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            // echo 'count : '.count($rs);
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
					$this->load->view('template/header',$data);
		            $this->load->view('preallpage',$data);
		            $this->load->view('template/footer');
            }
            else{
                $this->redemption($campid);
            }
    }

    function redemption($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        
        $data['img']= "";
        $data['bg'] = "";
        $data['campid']=$campid;
        // $data['imgbut']="";

        // echo 'campid : '.$campid.'<br>';
        $rs = $this->contentdb->select_data("*", "content",$campid,11)->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
					// $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
            }
        $this->load->view('template/header',$data);
		$this->load->view('bapage',$data);
		$this->load->view('template/footer');
    } 

    function pagecheck($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
        $data['detail']= "";
        $data['bg'] = "";
        // $data['imgbut']= "";
            $rs = $this->contentdb->select_i("*", "content",$campid,11)->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
					// $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
            }
        $this->load->view('template/header',$data);
		$this->load->view('ba_check',$data);
		$this->load->view('template/footer');
    }

    function checkcodeshop(){
        // $uri = $this->Main_function->html_chars(base_url());
        $code = $this->input->post('code');
        $campid = $this->input->post('campid');

        $rsg = $this->contentdb->select_shopcode("shop_code","store",$code)->result_array();
        if(count($rsg)== "1"){
            if($code != '111'){
                    $this->pass($campid);
                }
                else {
                    $this->nopass($campid); 
            }
        }
        else {
			$this->shop_warning($campid); 
        }
          
    }

    function pass($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
        $data['detail']="";
        $data['bg']="";

        $rs = $this->contentdb->select_data("*", "content",$campid,'12')->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
        }
        $this->load->view('template/header', $data);
		$this->load->view('passpage',$data);
		$this->load->view('template/footer');
    }
    
    function nopass($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']= "";
        $data['imgbut']= "";
        $data['bg']= "";
        
        $data['link_page']= $uri.'precontent/redemption/'.$campid;
        $rs = $this->contentdb->select_data("*", "content",$campid,"13")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
			$this->load->view('template/header',$data);
			$this->load->view('nopasspage',$data);
			$this->load->view('template/footer');
        }
    }

    function shop_warning($campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']= "";
        $data['imgbut']= "";
        $data['bg']= "";
        $data['link_page']= $uri.'precontent/redemption/'.$campid;

        $rs = $this->contentdb->select_data("*", "content",$campid,"14")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
			$this->load->view('template/header',$data);
			$this->load->view('code_warning',$data);
			$this->load->view('template/footer');
        }
    }
	
	function checkstorecode(){
		$code = $this->input->POST('code');
		echo $code;
	}
	
	function checkcode(){
		$result = array();
		$code = $this->input->post("code");
		
		if($code){
			$result = 'pass';
		}
		
		echo json_encode($result);
		exit;
	}
	
	function nodata($pageno=null,$campid=null){
		$data['img']= "";
		$data['detail']= "";
		$data['imgbut']= "";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];
            $rs = $this->contentdb->select_i("*", "content",$campid,$pageno)->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
					$data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
                    $this->load->view('template/header');
		            $this->load->view('nopage',$data);
		            $this->load->view('template/footer');
                }
            
	}
}
