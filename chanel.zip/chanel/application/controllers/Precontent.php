<?php
error_reporting(0);
class Precontent extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Content_model', 'contentdb');
        $this->load->helper('url');
    }
    public function index($cname=null, $gencode=null){
		
	}
    function allpage($pageno = null,$campid = null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['uri'] = $uri;
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        // $data['bg'] = "#f8f2e8";
        $data['bg'] = "";
        $data['type_style'] = "";
        $data['campid']= $campid;
        $data['page'] = $pageno;
        $pr_image = "";

        $page = $pageno + 1;
        $data['link_page']= $uri.'precontent/allpage/'.$page.'/'.$campid;

        // echo 'pagenext : '.$page.'<br>pageno : '.$pageno.'<br>';

        $sql = $this->contentdb->select_type("*", "campaign","AND id = '".$campid."'")->result_array();
        if(count($sql) > 0){
            foreach($sql as $c){
                $type = htmlspecialchars_decode(trim($c['type']));

                $data['type_style'] = $type;

                if($type == 'N'){
                    $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
                    // echo 'count : '.count($rs);
                    if(count($rs) > 0){
                        foreach($rs as $r){
                            $data['id'] = htmlspecialchars_decode(trim($r['id']));
                            $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                            $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                            $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                            $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                        }
                            $this->load->view('template/header',$data);
                            $this->load->view('preallpage',$data);
                            $this->load->view('template/footer');
                    }
                    else{
                        $this->redemption($campid);
                    }
                }else if($type == 'S'){
                    $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
                    // echo 'count : '.count($rs);
                    if(count($rs) > 0){
                        foreach($rs as $r){
                            $data['id'] = htmlspecialchars_decode(trim($r['id']));
                            $data['camp'] = htmlspecialchars_decode(trim($r['camp_id']));
                            $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                            $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                            $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                            $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));

                            $data['img_slider'] = array();

                            $slid = $this->contentdb->select_type("*", "content","AND camp_id  = '".$data['camp']."' AND page_no != '1' AND page_no != '11' AND page_no != '12' AND page_no != '13' AND page_no != '14' ")->result_array();
                            // echo 'countpage : '.count($slid);
                            if(count($slid) > 0){
                                foreach($slid as $s){
                                    $id = htmlspecialchars_decode(trim($s['id']));
                                    $campID = htmlspecialchars_decode(trim($s['camp_id']));
                                    $detail = htmlspecialchars_decode(trim($s['detail']));
                                    $image = htmlspecialchars_decode(trim($s['img_name']));
                                    $imgbut = htmlspecialchars_decode(trim($s['img_btn']));
                                    $bg = htmlspecialchars_decode(trim($s['code_bg']));

                                    $check_img = "0";
                                    if($image != ""){
                                        $ext_image = pathinfo($image, PATHINFO_EXTENSION);
                                        if($ext_image == "jpg" || $ext_image == "jpge" || $ext_image == "png"){
                                            if(!file_exists(FCPATH."uploads/f_content/$image")){ $check_img = "1"; }
                                        }

                                        if($check_img == "0"){
                                            $pr_image = '<img src="'.PATH_IMG.'f_content/'.$image.'?v='.date('his').'" class="img-responsive img-size" />';
                                        }
                                    }

                                        if($imgbut != ''){
                                            $select_img = '<div class="item">
                                                                <div>'.$pr_image.'</div>
                                                                <div class="btn-picture">
                                                                <a href="'.$uri.'precontent/redemption/'.$campID.'">
                                                                    <img src="'.PATH_IMG.'f_content/'.$imgbut.'?v='.date('his').'" class="img-fluid slider-btnimg" />
                                                                </div>
                                                                </a>
                                                            </div>';
                                        }else{
                                            $select_img = '<div class="item">'.$pr_image.'</div>';
                                        }

                                        $data['pr'][$id] = $select_img;
                                        array_push($data['img_slider'], $data['pr'][$id]);
                                }

                                
                            }
                        }

                            $this->load->view('template/header',$data);
                            $this->load->view('preallpage',$data);
                            $this->load->view('template/footer');
                    }else{
                        $this->redemption($campid);
                    }
                }

                

            }
        }
    }

    function datapage($pageno = null,$campid = null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['uri'] = $uri;
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['bg'] = "";
        $data['type_style'] = "";
        $data['page'] = $pageno;
        $data['data_dropdown'] = '';
        $select_pro  = '';
        $type  = '';

        $sql = $this->contentdb->select_type("*", "campaign","AND id = '".$campid."'")->result_array();
        if(count($sql) > 0){
            foreach($sql as $c){
                $type       = htmlspecialchars_decode(trim($c['type']));
                $select_pro = htmlspecialchars_decode(trim($c['select_product']));
                // echo 'type :'.$type;
                $data['type_style'] = $type;

                if($type == 'N'){
                    $gopage = 'page';
                    $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
                    // echo 'count : '.count($rs);
                    if(count($rs) > 0){
                        foreach($rs as $r){
                            $data['id'] = htmlspecialchars_decode(trim($r['id']));
                            $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                            $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                            $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                            $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                        }

                        if($select_pro == 'Y' && $pageno == 11){
                            $gopage = 'bapage';
                            $rs_pv = $this->contentdb->select_type("*", "dropdown_content","AND camp_id = '".$campid."' AND status != 'D'","id")->result_array();
                            if(count($rs_pv) > 0)
                            {
                                foreach($rs_pv as $ty)
                                {
                                    $list_id = htmlspecialchars_decode(trim($ty['id']));
                                    $detail = htmlspecialchars_decode(trim($ty['detail']));
                                    $select = '';
                                    
                                    $data['data_dropdown'] .= '<option value="'.$list_id.'"'.$select.'>'.$detail.'</option>';
                                }
                            }
                        }else if(($select_pro == 'N' || $select_pro == '') && $pageno == 11){
                            $gopage = 'bapage';
                            $rs = $this->contentdb->select_data("*", "content",$campid,11)->result_array();
                            if(count($rs) > 0){
                                foreach($rs as $r){
                                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                                }
                            }
                        }
                    }

                }else if($type == 'S'){
                    $gopage = 'preallpage';
                    $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
                    // echo 'count : '.count($rs);
                    if(count($rs) > 0){
                        foreach($rs as $r){
                            $data['id'] = htmlspecialchars_decode(trim($r['id']));
                            $data['camp'] = htmlspecialchars_decode(trim($r['camp_id']));
                            $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                            $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                            $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                            $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));

                            $data['img_slider'] = array();

                            $slid = $this->contentdb->select_type("*", "content","AND camp_id  = '".$data['camp']."' AND page_no != '1' AND page_no != '11' AND page_no != '12' AND page_no != '13' AND page_no != '14' ")->result_array();
                            // echo 'countpage : '.count($slid);
                            if(count($slid) > 0){
                                foreach($slid as $s){
                                    $id = htmlspecialchars_decode(trim($s['id']));
                                    $campID = htmlspecialchars_decode(trim($s['camp_id']));
                                    $detail = htmlspecialchars_decode(trim($s['detail']));
                                    $image = htmlspecialchars_decode(trim($s['img_name']));
                                    $imgbut = htmlspecialchars_decode(trim($s['img_btn']));
                                    $bg = htmlspecialchars_decode(trim($s['code_bg']));

                                    $check_img = "0";
                                    if($image != ""){
                                        $ext_image = pathinfo($image, PATHINFO_EXTENSION);
                                        if($ext_image == "jpg" || $ext_image == "jpge" || $ext_image == "png"){
                                            if(!file_exists(FCPATH."uploads/f_content/$image")){ $check_img = "1"; }
                                        }

                                        if($check_img == "0"){
                                            $pr_image = '<img src="'.PATH_IMG.'f_content/'.$image.'?v='.date('his').'" class="img-responsive img-size" />';
                                        }
                                    }

                                        if($imgbut != ''){
                                            $select_img = '<div class="item">
                                                                <div>'.$pr_image.'</div>
                                                                <div class="btn-picture">
                                                                <a href="#">
                                                                    <img src="'.PATH_IMG.'f_content/'.$imgbut.'?v='.date('his').'" class="img-fluid slider-btnimg" />
                                                                </div>
                                                                </a>
                                                            </div>';
                                        }else{
                                            $select_img = '<div class="item">'.$pr_image.'</div>';
                                        }

                                        $data['pr'][$id] = $select_img;
                                        array_push($data['img_slider'], $data['pr'][$id]);

                                        if($select_pro == 'Y' && $pageno == "11"){
                                            $gopage = 'bapage';
                                            $rs_pv = $this->contentdb->select_type("*", "dropdown_content","AND camp_id = '".$campid."' AND status != 'D'","id")->result_array();
                                            if(count($rs_pv) > 0)
                                            {
                                                foreach($rs_pv as $ty)
                                                {
                                                    $list_id = htmlspecialchars_decode(trim($ty['id']));
                                                    $detail = htmlspecialchars_decode(trim($ty['detail']));
                                                    $select = '';
                                                    
                                                    $data['data_dropdown'] .= '<option value="'.$list_id.'"'.$select.'>'.$detail.'</option>';
                                                }
                                            }
                                        }else if(($select_pro == 'N' || $select_pro == '') && $pageno == 11){
                                            $gopage = 'bapage';
                                            $rs = $this->contentdb->select_data("*", "content",$campid,11)->result_array();
                                            if(count($rs) > 0){
                                                foreach($rs as $r){
                                                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                                                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                                                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                                                }
                                            }
                                        }
                                }

                                
                            }
                        }
                    }
                }

            }

            $this->load->view('template/header',$data);
            $this->load->view($gopage,$data);
            $this->load->view('template/footer');
        }

            
    }



    function redemption($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        
        $data['img']= "";
        $data['bg'] = "";
        $data['campid']=$campid;
        $data['data_dropdown'] = "";

        // echo 'campid : '.$campid.'<br>';
        $sql = $this->contentdb->select_type("*", "campaign","AND id = '".$campid."'")->result_array();
        if(count($sql) > 0){
            foreach($sql as $c){
                $select_pro = htmlspecialchars_decode(trim($c['select_product']));
                
                if($select_pro == 'Y'){
                    $rs_pv = $this->contentdb->select_type("*", "dropdown_content","AND camp_id = '".$campid."' AND status != 'D'","id")->result_array();
					if(count($rs_pv) > 0)
					{
						foreach($rs_pv as $ty)
						{
							$list_id = htmlspecialchars_decode(trim($ty['id']));
							$detail = htmlspecialchars_decode(trim($ty['detail']));
                            $select = '';
                            
							$data['data_dropdown'] .= '<option value="'.$list_id.'"'.$select.'>'.$detail.'</option>';
						}
					}
                }

                $rs = $this->contentdb->select_data("*", "content",$campid,11)->result_array();
                if(count($rs) > 0){
                    foreach($rs as $r){
                        $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                        $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                        $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                    }
                }
            }
        }
        $this->load->view('template/header',$data);
		$this->load->view('bapage',$data);
		$this->load->view('template/footer');
    } 

    function pagecheck($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
        $data['detail']= "";
        $data['bg'] = "";
        // $data['imgbut']= "";
            $rs = $this->contentdb->select_i("*", "content",$campid,11)->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
					// $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
            }
        $this->load->view('template/header',$data);
		$this->load->view('ba_check',$data);
		$this->load->view('template/footer');
    }

    function checkcodeshop(){
        // $uri = $this->Main_function->html_chars(base_url());
        $code = $this->input->post('code');
        $campid = $this->input->post('campid');

        $rsg = $this->contentdb->select_shopcode("shop_code","store",$code)->result_array();
        if(count($rsg)== "1"){
            if($code != '111'){
                    $this->pass($campid);
            }else {
                    $this->nopass($campid); 
            }
        }
        else {
			$this->shop_warning($campid); 
        }
          
    }

    function pass($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
        $data['detail']="";
        $data['bg']="";

        $rs = $this->contentdb->select_data("*", "content",$campid,'12')->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
        }
        $this->load->view('template/header', $data);
		$this->load->view('passpage',$data);
		$this->load->view('template/footer');
    }
    
    function nopass($campid=null){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']= "";
        $data['imgbut']= "";
        $data['bg']= "";
        
        $data['link_page']= $uri.'precontent/redemption/'.$campid;
        $rs = $this->contentdb->select_data("*", "content",$campid,"13")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
			$this->load->view('template/header',$data);
			$this->load->view('nopasspage',$data);
			$this->load->view('template/footer');
        }
    }

    function shop_warning($campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']= "";
        $data['imgbut']= "";
        $data['bg']= "";
        $data['link_page']= $uri.'precontent/redemption/'.$campid;

        $rs = $this->contentdb->select_data("*", "content",$campid,"14")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['bg'] = htmlspecialchars_decode(trim($r['code_bg']));
                }
            }
			$this->load->view('template/header',$data);
			$this->load->view('code_warning',$data);
			$this->load->view('template/footer');
        }
    }
	
	function checkstorecode(){
		$code = $this->input->POST('code');
		echo $code;
	}
	
	function checkcode(){
		$result = array();
		$code = $this->input->post("code");
		
		if($code){
			$result = 'pass';
		}
		
		echo json_encode($result);
		exit;
	}
	
	function nodata($pageno=null,$campid=null){
		$data['img']= "";
		$data['detail']= "";
		$data['imgbut']= "";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];
            $rs = $this->contentdb->select_i("*", "content",$campid,$pageno)->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
					$data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
                    $this->load->view('template/header');
		            $this->load->view('nopage',$data);
		            $this->load->view('template/footer');
                }
            
	}
}
