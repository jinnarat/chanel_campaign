<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(E_ALL ^ E_NOTICE);
error_reporting(0);
ini_set('memory_limit', '512M'); 

class Campaign extends DB_Controller {
	
    function __construct()
    {
        parent::__construct();
		
		$this->load->model('Main_function');
		$this->load->model('Select_data');
		$this->load->model('Lists_model');		
		
		$check_session = $this->session->userdata('uicnname');
		
        if(!$check_session){						
            redirect(URL_Login);
        }
	}

	function camp_list(){
		$header['menu'] = 'campaign';
		$header['menu_sub'] = '';
		
		$data['uri'] = $this->Main_function->html_chars(base_url());
		
		$data['main_menu'] = "campaign";
		$data['id'] = "";
		$data['list_camp'] = "";
		$i = 1;
		$detail_id ="";
		
		
		$sql = $this->Select_data->select_data("* ,DATE_FORMAT(camp_start, '%d-%m-%Y %H:%i') as camp_start", "campaign", "AND status != 'D'")->result_array();
		if(count($sql) > 0){
			foreach($sql as $rs){
				$id = $rs['id'];
				$name = htmlspecialchars_decode(trim($rs['campname']), ENT_QUOTES);
				$main_url = htmlspecialchars_decode(trim($rs['main_url']), ENT_QUOTES);
				$start_date = strip_tags(htmlspecialchars_decode(trim($rs['camp_start']), ENT_QUOTES));
				$end_date = strip_tags(htmlspecialchars_decode(trim($rs['camp_end']), ENT_QUOTES));

				$data['list_camp'] .= "
					<tr>
						<td style='text-align: center;'>".$i."</td>
						<td style='text-align: left;'>".$name."</td>
						<td style=' text-align:left;'>".$start_date."</td>
						<td><a href='".URLFRONT."precontent/allpage/1/".$id."'target='_blank'><span data-feather='eye' ></span></a></td>
						<td style=' text-align:center;'>
							<a href='".$data['uri']."cmsadmin/campaign/page_lists/".$id."'><span data-feather='edit'></span></a>
						</td>
						<td style=' text-align:center;'>
							<a href='javascript:void(0)' onclick='DelAction(".$id.");'><font color='red'><span data-feather='trash-2'></span></font></a>
						</td>
					</tr>";
                        
				$i++;
			}
		}else{
			$data['list_camp'] = "
				<tr>
					<td align='center' colspan='5'>ไม่มีข้อมูล</td>									
				</tr>";
		}
		
		$this->load->view('cmsadmin/header', $header);
        $this->load->view('cmsadmin/Campaign/camp_list', $data);  
		$this->load->view('cmsadmin/footer');
	}
		
	function page_lists($id = null,$detail_id = null){		
		$c_name 				= 'Campaign';		
		$header['menu']			=  $c_name;
		
		$data['name']	="";
		$data['main_url']="";
		
		// $data['start_date'] = $this->Main_function->DatePreview(date('Y-m-d'));
		// $data['end_date']= $this->Main_function->DatePreview(date('Y-m-d'));;
		$date['end_date'] = "";
		$data['start_date']="";
		$data['status']	="";
		$data['type'] = "";
		$detail					= "";
		$camp_id				= $id;
		$detail_id  			= $detail_id;
		$display_input_topic	= "";
		$text_action			= "Hide";
		$text_action1			= "เพิ่มข้อมูล";
		
		$list_data			= "";
		$dropdown_list		= "";
		$data['select_product'] = "";

		// $date_start	 = $this->Main_function->convert_data($dateStart,"dateToDB");
		// $date_end	= $this->Main_function->convert_data($dateEnd,"dateToDB");
		
		$rs = $this->Select_data->select_data("* ,DATE_FORMAT(camp_start, '%d %b %Y') as camp_start, DATE_FORMAT(camp_end, '%d %b %Y') as camp_end","campaign","AND id = '".$camp_id."' ")->result_array();
		if(count($rs) > 0)
		{
			$camp_id				= $rs[0]['id'];
			$data['name']			= htmlspecialchars_decode($rs[0]['campname'],ENT_QUOTES);	
			$data['type']			= htmlspecialchars_decode($rs[0]['type'],ENT_QUOTES);		
			$data['main_url']		= htmlspecialchars_decode($rs[0]['main_url'],ENT_QUOTES);	
			$data['start_date']		= htmlspecialchars_decode($rs[0]['camp_start'],ENT_QUOTES);	
			$data['end_date']		= htmlspecialchars_decode($rs[0]['camp_end'],ENT_QUOTES);	
			$data['status']			= htmlspecialchars_decode($rs[0]['status'],ENT_QUOTES);	
			$data['select_product']	= htmlspecialchars_decode($rs[0]['select_product'],ENT_QUOTES);	

			$display_input_topic	= "";
			$text_action			= "Show";
			$text_action1			= $data['name']	." > แก้ไขข้อมูล";
			
		}
		
		$no	= 1;
		$rs_data = $this->Select_data->select_data("*","content","AND camp_id = '".$camp_id."'")->result_array();
		// echo "<PRE>";
		// print_r($rs_data);
		// echo "</PRE>";exit;
		if(count($rs_data) > 0) 
		{	
			foreach($rs_data as $rd)
			{
				$detail_id			 = $rd['id'];
				$img_name			 = $rd['img_name'];
				$page_no			 = $rd['page_no'];
				$image 				 = "<img src=".PATH_IMG."f_content/".$img_name." class='img-thumbnail' width='150' height='50px' >";
				$list_data	.= "<tr>
										<td style='text-align: center;'>".$no."</td>";
						if($img_name != ""){
							$list_data	.= "<td>".$image."</td>";
						}else{
							$list_data	.= "<td></td>";
						}				
			
				$list_data	.=		"<td>".htmlspecialchars_decode($rd['detail'],ENT_QUOTES)."</td>
									<td><a href='".URLFRONT."precontent/page/".$page_no."/".$camp_id."'target='_blank'><span data-feather='eye' ></span></a></td>
									<td><a href='".base_url()."cmsadmin/campaign/camp_form/".$camp_id."/".$detail_id."'><span data-feather='edit'></span></a></td>
									<td><a href='javascript:void(0)' onClick='delect($detail_id,$camp_id);'><font color='red'><span data-feather='trash-2'></span></a></td>
								
								</tr>";

									// <a href='javascript:void(0)' onclick='DelAction(".$id.");'><font color='red'><span data-feather='trash-2'></span></font></a>
				$no++;
			}
		}else{
			$list_data 	= "<tr>
									<td align='center' colspan=10>ไม่มีข้อมูล</td>									
							   </tr>";
		}	

		$i = 1;
		$ds = $this->Select_data->select_data("*","dropdown_content","AND camp_id = '".$camp_id."'")->result_array();
		if(count($ds) > 0) 
		{	
			foreach($ds as $dd)
			{
				$list_id		= htmlspecialchars_decode($dd['id'],ENT_QUOTES);	
				$detail			= htmlspecialchars_decode($dd['detail'],ENT_QUOTES);	
			
				$dropdown_list	.="<tr>
									<td style='text-align: center;'>".$i."</td>
									<td>".$detail."</td>
									<td><a href='".base_url()."cmsadmin/campaign/dropdown_form/".$camp_id."/".$list_id."'><span data-feather='edit'></span></a></td>
									<td><a href='javascript:void(0)' onClick='delectList($list_id,$camp_id);'><font color='red'><span data-feather='trash-2'></span></a></td>
								</tr>";
				$i++;
			}
		}else{
			$dropdown_list 	= "<tr>
									<td align='center' colspan=10>ไม่มีข้อมูล</td>									
							   </tr>";
		}	
		
				
		$data['camp_id']			= $camp_id;
		$data['subject_detail']		= $detail;	
		$data['display_input_topic']= $display_input_topic;
		$data['text_action']		= $text_action;
		$data['text_action1']		= $text_action1;
		$data['detail_id']			= $detail_id;
		
		$data['list_data']			= $list_data;
		$data['dropdown_list']		= $dropdown_list;
		
		$this->load->view('cmsadmin/header',$header);
        $this->load->view('cmsadmin/'.$c_name.'/page_list',$data);  
		$this->load->view('cmsadmin/footer');
    }    	

	function update_campaign()
	{	$uri = $this->Main_function->html_chars(base_url());		
		$id					= $this->input->post('input_id');		
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']= date("Y-m-d H:i:s");	
		// $data['status']	= htmlspecialchars($this->input->post('status'),ENT_QUOTES);		
		$data['campname'] 	= htmlspecialchars($this->input->post('topic'),ENT_QUOTES);			
		$data['type'] 		= htmlspecialchars($this->input->post('type'),ENT_QUOTES);
		$data['select_product'] = htmlspecialchars($this->input->post('exampleCheck'),ENT_QUOTES);		
		// $data['camp_end'] 	= htmlspecialchars($this->input->post('end_date'),ENT_QUOTES);	

		if($this->input->post('dateStart')){
			$start_date = htmlspecialchars(trim($this->input->post('dateStart')),ENT_QUOTES);
			// $data['camp_start'] = $this->Main_function->DateDecode($start_date);
			$data['camp_start'] = $this->Main_function->convert_data($start_date,"dateToDB");
		}
		if($this->input->post('dateStart')){
			$end_date = htmlspecialchars(trim($this->input->post('dateEnd')),ENT_QUOTES);
			$data['camp_end'] = $this->Main_function->convert_data($end_date,"dateToDB");
		}

		// $date_start	 = $this->Main_function->convert_data($dateStart,"dateToDB");
		// $date_end	= $this->Main_function->convert_data($dateEnd,"dateToDB");
		
		
		if($id == "")
		{	$data['createby'] 		= $this->session->userdata('uicnid');
			$data['create_date']	= date("Y-m-d H:i:s");
			$data['main_url'] 		= htmlspecialchars($this->input->post('Domain'),ENT_QUOTES)."/";
			$data['status']			= 'A';
			if($this->db->insert('campaign', $data))
			{
				$result = "pass";
				$res = $this->db->query("SELECT @@IDENTITY as insert_id")->row_array();
				$max_id = $res['insert_id'];		
			}else{
				$result = "fail";
			}
		}else{	
			$data['main_url'] 	= htmlspecialchars($this->input->post('Domain'),ENT_QUOTES);		
			$max_id = $id;
			$this->db->where('id', $id);
			if($this->db->update('campaign', $data))
			{
				$result = "pass";				
			}else{
				$result = "fail";
			}
		}
		
		if($result == "pass")
		{						
			echo "<script>alert('Update data already.'); location.href='".base_url()."cmsadmin/campaign/page_lists/".$max_id."';</script>";		
		}	
	}	

	function dropdown_form($camp_id=null,$list_id=null)
	{
		$c_name 				= 'Campaign';		
		$header['menu']			= 'm_'.$c_name;		
		$detail					= "";			
		
		$data['camp_id']		= $camp_id;
		$data['list_id']		= $list_id;
		$data['id']				= "";
		$data['dropdown_text']	= "";
		$data['text_action']	= "เพิ่มข้อมูล";
		
		if($list_id != null || $list_id != '')
		{
			$rs = $this->Select_data->select_data("*","dropdown_content"," AND camp_id = $camp_id AND id = $list_id ")->result_array();
			$data['id']				= htmlspecialchars_decode($rs[0]['id'],ENT_QUOTES);
			$data['dropdown_text']	= htmlspecialchars_decode($rs[0]['detail'],ENT_QUOTES);	
			$data['text_action']	= "แก้ไขข้อมูล";
		}
		
		
		$this->load->view('cmsadmin/header',$header);
        $this->load->view('cmsadmin/'.$c_name.'/dropdown_form',$data);  
		$this->load->view('cmsadmin/footer');
	}

	function update_droplist()
	{	$uri = $this->Main_function->html_chars(base_url());		
		$camp_id	= $this->input->post('camp_id');	
		$id		= $this->input->post('list_id');
		$data['update_date']= date("Y-m-d H:i:s");	
		$data['detail'] 	= htmlspecialchars($this->input->post('dropdown_text'),ENT_QUOTES);	
		$data['camp_id']	= $camp_id;
		
		if($id == "")
		{	
			$data['create_date']	= date("Y-m-d H:i:s");
			$data['status']			= 'A';
			if($this->db->insert('dropdown_content', $data))
			{
				$result = "pass";
				$res = $this->db->query("SELECT @@IDENTITY as insert_id")->row_array();
				$max_id = $res['insert_id'];		
			}else{
				$result = "fail";
			}
		}else{			
			$max_id = $id;
			$this->db->where('id', $id);
			if($this->db->update('dropdown_content', $data))
			{
				$result = "pass";				
			}else{
				$result = "fail";
			}
		}
		
		if($result == "pass")
		{						
			echo "<script>alert('Update data already.'); location.href='".base_url()."cmsadmin/campaign/dropdown_form/".$camp_id."/".$max_id."';</script>";		
		}	
	}	
		
	function camp_form($camp_id=null,$detail_id=null)
	{
		$c_name 				= 'Campaign';		
		$header['menu']			= 'm_'.$c_name;		
		$detail					= "";			
		
		$data['camp_id']		= $camp_id;
		$data['detail_id']		= $detail_id;
		$data['id']				= "";
		$data['detail']			= "";
		$data['img_name']		= "";
		$data['img_btn']		= "";
		$data['page_no']		= "";
		$data['status']			= "";
		$data['code_bg']		= "";  
		$data['text_action']			= "เพิ่มข้อมูล";
		
		if($detail_id != null || $detail_id != '')
		{
			$rs = $this->Select_data->select_data("*","content"," AND camp_id = $camp_id AND id = $detail_id ")->result_array();
			$data['id']				= htmlspecialchars_decode($rs[0]['id'],ENT_QUOTES);
			$data['detail']			= htmlspecialchars_decode($rs[0]['detail'],ENT_QUOTES);	
			$data['img_btn']		= htmlspecialchars_decode($rs[0]['img_btn'],ENT_QUOTES);
			$data['img_name']		= htmlspecialchars_decode($rs[0]['img_name'],ENT_QUOTES);
			$data['status']			= htmlspecialchars_decode($rs[0]['status'],ENT_QUOTES);
			$data['page_no']		= htmlspecialchars_decode($rs[0]['page_no'],ENT_QUOTES);
			$data['code_bg']		= htmlspecialchars_decode($rs[0]['code_bg'],ENT_QUOTES);
			$data['text_action']	= "แก้ไขข้อมูล";
		}
		
		
		$this->load->view('cmsadmin/header',$header);
        $this->load->view('cmsadmin/'.$c_name.'/camp_form',$data);  
		$this->load->view('cmsadmin/footer');
	}
	
	function update_content(){	
		
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']	= date("Y-m-d H:i:s");	
		
		$camp_id			= $this->input->post('camp_id');
		$detail_id			= $this->input->post('detail_id');
	
		$data['camp_id']	= $camp_id;
		$data['detail'] 	= htmlspecialchars($this->input->post('detail'),ENT_QUOTES);			
		$data['status'] 	= htmlspecialchars($this->input->post('status'),ENT_QUOTES);
		$data['page_no'] 	= htmlspecialchars($this->input->post('page_no'),ENT_QUOTES);
		$data['code_bg'] 	= htmlspecialchars($this->input->post('code_bg'),ENT_QUOTES);


		$folderFile     = "f_content/"; 
		$MKfolder   	= PATHFRONTUPLOAD.$folderFile; 
        $img_name       = '';
		
		if (!file_exists($MKfolder)) {
			mkdir($MKfolder, 0777, true);
		} 
		if(!empty($_FILES["inputImg"]['name'])){
			$file_original		= $_FILES["inputImg"]["name"];
            $file_content_type	= $_FILES["inputImg"]["type"];
			$ext 				= pathinfo($file_original, PATHINFO_EXTENSION);	
            $img_name 			= 'camp_'.date("YmdHis").".".$ext;
			// echo '../'.PATHFRONTUPLOAD.$folderFile.$img_name; exit;
			$file_path 			= PATHFRONTUPLOAD.$folderFile.$img_name;	
			if(move_uploaded_file($_FILES["inputImg"]["tmp_name"], $file_path)){
				
				$data['img_name'] = $img_name;
			}
		}

		$img_btn = "";

		if(!empty($_FILES["inputBtn"]['name'])){
			$size = getimagesize($_FILES['inputBtn']["tmp_name"]);  
			//  print_r ($size); exit;
			$img_width = $size[0];
			$img_height = $size[1];
			
			// if($img_width < 500|| $img_height < 300){
			// 	echo "<script>alert('Please check the file and file size must be at least 500 * 300 pixels!'); location.href='".$uri."cmsadmin/campaign/page_list';</script>";
			// 	exit;
			// }
				
			// if($_FILES['inputBtn']['size'] > 524288) { 
			// 	echo "<script>alert('Warning !! file size image is over 512 KB.'); location.href='".$uri."cmsadmin/campaign/page_list';</script>";
			// 	exit;
			// }
			
			
			$file_original		= $_FILES["inputBtn"]["name"];
            $file_content_type	= $_FILES["inputBtn"]["type"];
			$ext 				= pathinfo($file_original, PATHINFO_EXTENSION);	
            $img_btn			= 'campBtn_'.date("YmdHis").".".$ext;
			// echo '../'.PATHFRONTUPLOAD.$folderFile.$img_btn; exit;
			$file_path 			= PATHFRONTUPLOAD.$folderFile.$img_btn;	
			if(move_uploaded_file($_FILES["inputBtn"]["tmp_name"], $file_path)){
				
				$data['img_btn'] = $img_btn;
			}

			
		}
		
		if($detail_id == "")
		{	
			$data['createby'] 		= $this->session->userdata('uicnid');
			$data['create_date']	= date("Y-m-d H:i:s");	
			if($this->db->insert('content', $data))
			{
				$result = "pass";
				$res 	= $this->db->query("SELECT @@IDENTITY as insert_id")->row_array();
				$max_id = $res['insert_id'];		
			}else{
				$result = "fail";
			}
		}else{			
			$max_id = $detail_id;
			$this->db->where('id', $detail_id);
			if($this->db->update('content', $data))
			{
				$result = "pass";				
			}else{
				$result = "fail";
			}
		}
		
		if($result == "pass")
		{						
			echo "<script>alert('Update data already.'); location.href='".base_url()."cmsadmin/campaign/camp_form/".$camp_id."/".$max_id."';</script>";		
		}		
		
	}
	
	function delete_camp()
	{
		$detail_id			= $this->input->post('id');
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']	= date("Y-m-d H:i:s");	
		$data['status']= "D";
		$this->db->where('id', $detail_id);
		if($this->db->update('campaign', $data))
		{
			$result = "pass";				
		}else{
			$result = "fail";
		}
		echo $result;
	}

	function delete_data()
	{
		$id			= $this->input->post('id');
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']	= date("Y-m-d H:i:s");	
		$data['status']= "D";

		$this->db->where('id', $id);
		if($this->db->update('content', $data))
		{
			$result = "pass";				
		}else{
			$result = "fail";
		}

		echo $result;
	}

	function delete_droplist()
	{
		$id			= $this->input->post('id');
		$data['update_date']	= date("Y-m-d H:i:s");	
		$data['status']= "D";

		$this->db->where('id', $id);
		if($this->db->update('dropdown_content', $data))
		{
			$result = "pass";				
		}else{
			$result = "fail";
		}

		echo $result;
	}
}
?>