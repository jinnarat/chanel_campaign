<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
   error_reporting(0);
    ini_set('memory_limit', '1024M');
    ini_set('sqlsrv.ClientBufferMaxKBSize','524288'); 
    ini_set('pdo_sqlsrv.client_buffer_max_kb_size','524288');
   
   class Export_excel extends DB_Controller {
   
       function __construct()
       {
           parent::__construct();
           $this->load->model('Select_data');
           $this->load->model('Main_function');
           
        //    $config['allowed_types'] = 'xlsx|xls';
        //    $config['remove_spaces'] = TRUE;
        //    $this->load->library('upload', $config);
           date_default_timezone_set('Asia/Bangkok');
       }
    //    function index(){ 
           
    //    }
       
       function export_data(){
       
        require_once APPPATH . "/third_party/PHPExcel.php";

        $id = trim(htmlspecialchars($this->input->get('id'),ENT_QUOTES));

        


        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->setTitle('หน้า1');
        // $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:E1');
        // $objPHPExcel->getActiveSheet()->setCellValue('A1', 'ข้อมูลประจำวันที่  '.date('d-M-Y H:i:s'));
        $objPHPExcel->getActiveSheet()->setCellValue('A1', 'Phone');
        $objPHPExcel->getActiveSheet()->setCellValue('B1', 'Url');
        
        for($s='A'; $s<='S'; $s++){
			$objPHPExcel->getActiveSheet()->getColumnDimension(''.$s.'')->setAutoSize(true);
        }
        $objPHPExcel->getActiveSheet()->getStyle('A1:B1')->applyFromArray(
            array( 
                'font'    	=> array('bold'	=> true	, 'color' => array('rgb' => '000000')),
				'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,	) ,
				'borders' 	=> array('allborders' 	=> array( 'style' => PHPExcel_Style_Border::BORDER_THIN ) 	),
				'fill' 		=> array('type'	=> PHPExcel_Style_Fill::FILL_SOLID, 'color'		=> array('rgb' => 'CBCBCB') )
            )
        ); 
        $line=2;
        $i=1;
        $rs = $this->Select_data->url_export($id)->result_array();
        
		$row = 1;

        foreach($rs as $td){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$line.'',$td['tel_no']);
            // $objPHPExcel->getActiveSheet()->setCellValueExplicit('C'.$line.'',$td['id_card'], PHPExcel_Cell_DataType::TYPE_STRING);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$line.'',URLFRONT.$td['url_gen']);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$line.'')->applyFromArray(
                array(
                    'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,) 
                )
            ); 
            $i++;
            $line++;
        }
       
        $objPHPExcel->setActiveSheetIndex(0);
        $filename= "ChanelCampaign(sentsms)".date("(d-M-Y H.i.s)").'.xlsx';
        header('Content-Type: application/vnd.ms-excel'); //mime type
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma:no-cache');
        header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
        header('Cache-Control: max-age=0'); //no cache
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');     
        // ob_end_clean();      
        $objWriter->save('php://output');
       }

       function export_report(){
       
        require_once APPPATH . "/third_party/PHPExcel.php";


        // $date_st = $this->Main_function->convert_data($this->input->post('date_st'),'dateToDB');
        $tel        = trim(htmlspecialchars($this->input->get('tel'),ENT_QUOTES));
        $dateStart  = trim(htmlspecialchars($this->input->get('dateStart'),ENT_QUOTES));
        $dateEnd    = trim(htmlspecialchars($this->input->get('dateEnd'),ENT_QUOTES));
        $code       = trim(htmlspecialchars($this->input->get('scode'),ENT_QUOTES));
        $name       = trim(htmlspecialchars($this->input->get('sname'),ENT_QUOTES));
        $id         = trim(htmlspecialchars($this->input->get('camp_id'),ENT_QUOTES));

        $date_start	 = $this->Main_function->convert_data($dateStart,"dateToDB");
        $date_end	= $this->Main_function->convert_data($dateEnd,"dateToDB");
        

        $sql = $this->Select_data->Select_data("*", "campaign","AND id = '".$id."'")->result_array();
        if(count($sql) > 0){
            foreach($sql as $c){
                $select_pro = htmlspecialchars_decode(trim($c['select_product']));
            }
        }

        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->setTitle('หน้า1');
        // $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:E1');
        // $objPHPExcel->getActiveSheet()->setCellValue('A1', 'ข้อมูลประจำวันที่  '.date('d-M-Y H:i:s'));
        $objPHPExcel->getActiveSheet()->setCellValue('A1', 'ลำดับ');
        $objPHPExcel->getActiveSheet()->setCellValue('B1', 'ชื่อกิจกรรม');
        $objPHPExcel->getActiveSheet()->setCellValue('C1', 'วันที่เริ่มกิจกรรม');
        $objPHPExcel->getActiveSheet()->setCellValue('D1', 'เบอร์โทรศัพท์');
        $objPHPExcel->getActiveSheet()->setCellValue('E1', 'วันที่คลิก URL');
        $objPHPExcel->getActiveSheet()->setCellValue('F1', 'วันที่กดใช้สิทธิ์');
        $objPHPExcel->getActiveSheet()->setCellValue('G1', 'URL');
        $objPHPExcel->getActiveSheet()->setCellValue('H1', 'รหัสสาขา');
        $objPHPExcel->getActiveSheet()->setCellValue('I1', 'ชื่อสาขา');

        if($select_pro == 'Y'){
            $objPHPExcel->getActiveSheet()->setCellValue('J1', 'ชื่อผลิตภัณฑ์ที่รับ');
            for($s='A'; $s<='S'; $s++){
                $objPHPExcel->getActiveSheet()->getColumnDimension(''.$s.'')->setAutoSize(true);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:J1')->applyFromArray(
                array( 
                    'font'    	=> array('bold'	=> true	, 'color' => array('rgb' => '000000')),
                    'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,	) ,
                    'borders' 	=> array('allborders' 	=> array( 'style' => PHPExcel_Style_Border::BORDER_THIN ) 	),
                    'fill' 		=> array('type'	=> PHPExcel_Style_Fill::FILL_SOLID, 'color'		=> array('rgb' => 'CBCBCB') )
                )
            ); 

        }else{
            for($s='A'; $s<='S'; $s++){
                $objPHPExcel->getActiveSheet()->getColumnDimension(''.$s.'')->setAutoSize(true);
            }
            $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray(
                array( 
                    'font'    	=> array('bold'	=> true	, 'color' => array('rgb' => '000000')),
                    'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,	) ,
                    'borders' 	=> array('allborders' 	=> array( 'style' => PHPExcel_Style_Border::BORDER_THIN ) 	),
                    'fill' 		=> array('type'	=> PHPExcel_Style_Fill::FILL_SOLID, 'color'		=> array('rgb' => 'CBCBCB') )
                )
            ); 
        }
        
       
       
    // echo $date_start."<br>".$date_end."<br>".$tel."<br>".$url."<br>".$name."<br>".$code."<br>".$camp_id; exit;
    if(!empty($date_start) && !empty($date_end)){
        $condition  .= "AND sms_no.url_start  BETWEEN '$date_start 00:00:00.000' AND '$date_end 23:59:59.000' AND sms_no.url_end  BETWEEN '$date_start 00:00:00.000' AND '$date_end 23:59:59.000' OR sms_no.url_end = '0000-00-00 00:00:00.000'";                                       
    }

    if(!empty($code)){
        $condition  .= "AND  store.shop_code LIKE '%$code%'";                                                                    
    }

    if(!empty($name)){
        $condition  .= "AND store.shop_name LIKE '%$name%'";                                                                    
    }
    if(!empty($tel)){
        $condition  .= "AND sms_no.tel_no LIKE '%$tel%'";                                                                     
    }

    if(!empty($url)){
        $condition  .= "AND campaign.main_url LIKE '%$url%' OR sms_no.url_gen LIKE '%$url%'";                                                                   
    }

		

        $line=2;
        $i=1;
        
        $rs = $this->Select_data->report($id, $condition)->result_array();
        $row = 1;

        foreach($rs as $td){

            $objPHPExcel->getActiveSheet()->setCellValue('A'.$line.'',$i);
            // $objPHPExcel->getActiveSheet()->setCellValue('A'.$line.'',$td['tel_no']);
            // $objPHPExcel->getActiveSheet()->setCellValueExplicit('C'.$line.'',$td['id_card'], PHPExcel_Cell_DataType::TYPE_STRING);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$line.'',$td['campname']);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$line.'',$td['camp_start']);
            $objPHPExcel->getActiveSheet()->setCellValueExplicit('D'.$line.'',$td['tel_no']);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$line.'',$td['url_start']);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$line.'',$td['url_end']);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$line.'',URLFRONT.$td['url_gen']);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$line.'',$td['shop_code']);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$line.'',$td['shop_name']);

            if($td['product_id'] != '' && $td['product_id'] != 0){
                $objPHPExcel->getActiveSheet()->setCellValue('J'.$line.'',$td['name_list']);
            }

           
            $objPHPExcel->getActiveSheet()->getStyle('J'.$line.'')->applyFromArray(
                array(
                    'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,) 
                )
            ); 
            $i++;
            $line++;
        }
       
        $objPHPExcel->setActiveSheetIndex(0);
        $filename= "ChanelCampaign-sms".date("(d-M-Y H.i.s)").'.xlsx';
        header('Content-Type: application/vnd.ms-excel'); //mime type
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma:no-cache');
        header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
        header('Cache-Control: max-age=0'); //no cache
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');     
        // ob_end_clean();      
        $objWriter->save('php://output');
       }
   }
   ?>