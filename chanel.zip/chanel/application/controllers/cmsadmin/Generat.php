<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
ini_set('memory_limit', '1024M');
ini_set('max_execution_time', '0');
class Generat extends DB_Controller {
	
	function __construct()
    {
        parent::__construct();
		$this->load->model('Select_data');
		$this->load->model('Lists_model');
		$chk_userlogin = $this->session->userdata('uicnname');
        if(!$chk_userlogin){
			redirect(URL_Login);
        }
    }
		
    function index(){
		$header['menu'] = 'about';
		$header['menu_sub'] = '';
		
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data['data_content'] = '';
		
		$this->load->view('cmsadmin/header', $header);
        $this->load->view('cmsadmin/mainpage', $data);  
		$this->load->view('cmsadmin/footer');
	}
	
	function camp_list(){
		$data['uri'] = $this->Main_function->html_chars(base_url());
		
		$data['id'] = "";
		$data['list_camp'] = "";
		$i = 1;
		$detail_id ="";
		
		
		$sql = $this->Select_data->select_data("* ,DATE_FORMAT(camp_start, '%d-%m-%Y %H:%i') as camp_start", "campaign", "AND status != 'D'")->result_array();
		if(count($sql) > 0){
			foreach($sql as $rs){
				$id = $rs['id'];
				$name = htmlspecialchars_decode(trim($rs['campname']), ENT_QUOTES);
				$main_url = htmlspecialchars_decode(trim($rs['main_url']), ENT_QUOTES);
				$start_date = strip_tags(htmlspecialchars_decode(trim($rs['camp_start']), ENT_QUOTES));
				$end_date = strip_tags(htmlspecialchars_decode(trim($rs['camp_end']), ENT_QUOTES));

				$data['list_camp'] .= "
					<tr>
						<td style='text-align: center;'>".$i."</td>
						<td style='text-align: left;'>".$name."</td>
						<td style=' text-align:left;'>".$start_date."</td>
						<td style=' text-align:center;'>
							<a href='".$data['uri']."cmsadmin/generat/gen_list/".$id."'><span data-feather='edit'></span></a>
						</td>
						<td style=' text-align:center;'>
							<a href='javascript:void(0)' onclick='DelAction(".$id.");'><font color='red'><span data-feather='trash-2'></span></font></a>
						</td>
					</tr>";
                        
				$i++;
			}
		}else{
			$data['list_camp'] = "
				<tr>
					<td align='center' colspan='5'>ไม่มีข้อมูล</td>									
				</tr>";
		}
		
		$this->load->view('cmsadmin/header', $header);
        $this->load->view('cmsadmin/Generat/camp_list', $data);  
		$this->load->view('cmsadmin/footer');
	}
	
	function gen_list($id = null,$detail_id = null){
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$uri = $data['uri'];
		$camp_id				= $id;
		$detail_id  			= $detail_id;
		$data['camp_id'] = "";
		$data['tel_no'] = "";
		$data['id'] = "";
		$data['url_encode'] = array();

        $checkurlgen = 0;
		$rs = $this->Select_data->select_data("*", "sms_no")->result_array();
			if(count($rs) > 0){
				foreach($rs as $value){
					// $idx = htmlspecialchars_decode(trim($value['id']),ENT_QUOTES);
					$data['id'] = htmlspecialchars_decode(trim($value['id']),ENT_QUOTES);
					$data['camp_id'] = htmlspecialchars_decode(trim($value['camp_id']),ENT_QUOTES);
					$data['tel_no'] = htmlspecialchars_decode(trim($value['tel_no']),ENT_QUOTES);
					array_push($data['url_encode'],$data['tel_no'].$data['camp_id']);
				
				}
				
		}
		$data['data_list'] = "";
		$i = 1;
		
		$name = $this->Select_data->select_data("campname", "campaign","AND id = '".$camp_id."' ")->result_array();
		if(count($name) > 0){
			foreach($name as $rd){
				$data['camp_name'] = htmlspecialchars_decode(trim($rd['campname']), ENT_QUOTES);
			}
		}
		
		$sql = $this->Select_data->select_data("*", "sms_no", "AND camp_id = $camp_id")->result_array();
		if(count($sql) > 0){
			foreach($sql as $rs){
				$status = "";
				if($rs['status'] == "A"){
					$status = "Active";
				}else if($rs['status'] == 'I'){				
					$status = "Inactive";
				}
				
				$id = $rs['id'];
				$camp_id = htmlspecialchars_decode(trim($rs['camp_id']), ENT_QUOTES);
				$tel_no = htmlspecialchars_decode(trim($rs['tel_no']), ENT_QUOTES);
				$data['url_gen'] = htmlspecialchars_decode(trim($rs['url_gen']), ENT_QUOTES);
				
				$data['data_list'] .= "
					<tr>
						<td style='text-align: center;'>".$i."</td>
						<td style='text-align: left;'>".$tel_no."</td>";

				$rd = $this->Select_data->url_sent($id)->result_array();
				
				if(count($rd) > 0){
					foreach($rd as $r){
						$url_sent = htmlspecialchars_decode(trim($r['url_gen']), ENT_QUOTES);
						$data['camp_name'] = htmlspecialchars_decode(trim($r['campname']), ENT_QUOTES);
						
						$data['data_list'] .= "
										<td style=' text-align:center;'>".URLFRONT. $url_sent."</td>";
					}
				}

				$data['data_list'] .= "
						<td style=' text-align:center;'>
						</td>
						<td style=' text-align:center;'>
							<a href='javascript:void(0)' onclick='DelAction(".$id.");'><font color='red'><span data-feather='trash-2'></span></font></a>
						</td>
					</tr>";
                        
				$i++;
					
			}
		}else{
			// $data['data_list'] = "
			// 	<tr>
			// 		<td align='center' colspan='5'>ไม่มีข้อมูล</td>									
			// 	</tr>";
		}

		$data['camp_id'] = $camp_id;
		
		$this->load->view('cmsadmin/header');
        $this->load->view('cmsadmin/Generat/gen_list', $data);  
		$this->load->view('cmsadmin/footer');
	}

	function url_update($id=null){
		$camp_id	= $id;
		$data['tel_no'] = "";
		$data['id'] = "";
		$data['url_encode'] = array();
		$data['url_gen'] = array();

		$rs = $this->Select_data->select_data("*", "sms_no","AND url_encode  = ' ' AND camp_id = $camp_id OR url_gen  = ' '  ")->result_array();
			if(count($rs) > 0){
				foreach($rs as $value){
					$data['id'] = htmlspecialchars_decode(trim($value['id']),ENT_QUOTES);
					$data['camp_id'] = htmlspecialchars_decode(trim($value['camp_id']),ENT_QUOTES);
					$data['tel_no'] = htmlspecialchars_decode(trim($value['tel_no']),ENT_QUOTES);
					$data['url_encode'][$data['id']] = base64_encode($data['tel_no'].$data['camp_id']);
					$data['url_encode'][$data['id']] = str_replace("=","cnB",$data['url_encode'][$data['id']]);

					do {
						$data['url_gen'][$data['id']] = $this->Main_function->genCodeUrl(5);
						$cond = " AND url_gen = '" .$data['url_gen'][$data['id']] . "'";
						$rs_chk_code = $this->Select_data->select_data("*", "sms_no", $cond)->result_array();
						// echo count($rs_chk_code);
					} while (count($rs_chk_code)  > 0);
				// print_r($data['url_gen'] ); exit;

				}
		}else{
			echo "<script>alert('Cannot generat url because the information is complete..'); location.href='".base_url()."cmsadmin/generat/gen_list/".$camp_id."';</script>";
		}

		$countpass = 0;
		$countfail = 0;
		$counttest = 0;
		$counttest2 = 0;
		foreach ($data['url_encode'] as $key => $value) {
			$data1['url_encode'] = $value;
			$data1['create_date'] = date("Y-m-d H:i:s");	
			$data1['createby'] = $this->session->userdata('uicnid');
			$data2['url_gen'] = $data['url_gen'][$key];

				$this->db->where('id',$key);
				if($this->db->update('sms_no', $data1)){
		
					$this->db->where('id',$key);
					if($this->db->update('sms_no', $data2)){
							$result = "data2 pass";
							$countfail++;
					}else{
						$result = "fail";
						$counttest2++;
					}
		
					$result = "pass";
					$countpass++;

				}else{
					$result = "fail";
					$counttest++;
				}
		}
		// echo $countpass."<br>";
		// echo $countfail."<br>";
		// echo $counttest."<br>";
		// echo $counttest2."<br>";

		if($result == "pass"){
			echo "<script>alert('Generat Success.'); location.href='".base_url()."cmsadmin/generat/gen_list/".$camp_id."';</script>";
		}else{
			echo "<script>alert('Can\'t save data.'); location.href='".base_url()."cmsadmin/generat/gen_list/".$camp_id."';</script>";
		}

	}

	function update_phone()
	{	$uri = $this->Main_function->html_chars(base_url());		
		$camp_id		= $this->input->post('camp_id');
		$data['tel_no']	= $this->input->post('phone');	
		$data['status'] = "N";	
		$data['status_new'] = "N";	
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']= date("Y-m-d H:i:s");		
		$data['camp_id'] = $camp_id;
		
		if($camp_id != "")
		{	
			if($this->db->insert('sms_no', $data))
			{
				echo "<script>alert('Update data already.'); location.href='".base_url()."cmsadmin/generat/gen_list/".$camp_id."';</script>";
					
			}else{
				$resul = "fail";
				echo "<script>alert('fail !!!!'); location.href='".base_url()."cmsadmin/generat/gen_list/".$camp_id."';</script>";
			}
		}	
	}	

	function delete_data()
	{
		$id					= $this->input->post('id');
		$camp_id			= $this->input->post('camp_id');

		// echo $id; exit;
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']	= date("Y-m-d H:i:s");	
		$data['status']= "D";

		// echo $id; exit;

		$this->db->where('id', $id);
		if($this->db->update('sms_no', $data))
		{
			$result = "pass";				
		}else{
			$result = "fail";
		}


		echo $result; 
	}

	function delete_camp()
	{
		$detail_id			= $this->input->post('id');
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']	= date("Y-m-d H:i:s");	
		$data['status']= "D";
		$this->db->where('id', $detail_id);
		if($this->db->update('campaign', $data))
		{
			$result = "pass";				
		}else{
			$result = "fail";
		}
		echo $result;
	}


}
?>
