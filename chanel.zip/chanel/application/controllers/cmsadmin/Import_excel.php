<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// error_reporting(0);
ini_set('memory_limit', '-1');

class Import_excel extends DB_Controller{

    public function __construct() {
        parent::__construct();
        $this->load->model('Select_data');
        $this->load->model('Main_function');
        $this->load->model('Import_model', 'import');
    }

    // upload xlsx|xls file
    public function index() {
        $data['page'] = 'import';
        $data['title'] = 'Import XLSX | TechArise';
        $this->load->view('import/index', $data);
    }
    // import excel data
    public function save() {
        
        $this->load->library('excel');
        $this->load->library('upload');
        $idcampign = $this->input->post('idcampign');
        $status = $this->input->post('status');
        $new_status = $this->input->post('new_status');

        if ($this->input->post('importfile')) {
            $path = UPLOAD_IMPORT_PATH;

            $config['upload_path'] = $path;
            $config['allowed_types'] = 'xlsx|xls|jpg|png';
            $config['remove_spaces'] = TRUE;
            $this->upload->initialize($config);
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('userfile')) {
                $error = array('error' => $this->upload->display_errors());
            } else {
                $data = array('upload_data' => $this->upload->data());
            }
            
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            $inputFileName = $path . $import_xls_file;
            try {
                $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
                $objReader = PHPExcel_IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch (Exception $e) {
                die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
                        . '": ' . $e->getMessage());
            }
            $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
            
            $arrayCount = count($allDataInSheet);
            $flag = 0;
            $createArray = array('No.', 'VIP Telephone Txt');
            $makeArray = array('No.' => 'No.', 'VIP Telephone Txt' => 'VIP Telephone Txt');
            $SheetDataKey = array();
            foreach ($allDataInSheet as $dataInSheet) {
                foreach ($dataInSheet as $key => $value) {
                    if (in_array(trim($value), $createArray)) {
                        $value = preg_replace('/\s+/', '', $value);
                        $SheetDataKey[trim($value)] = $key;
                    } else {
                        
                    }
                }
            }
           
            $data = array_diff_key($makeArray, $SheetDataKey);

            if (!empty($data)) {
                $flag = 1;
            }
           
            //  print_R($SheetDataKey['VIPTelephoneTxt']);exit;
            if ($flag == 1) {
                for ($i = 2; $i <= $arrayCount; $i++) {
                    $addresses = array();
                    $Phone = $SheetDataKey['VIPTelephoneTxt'];
                    $Phone = filter_var(trim($allDataInSheet[$i][$Phone]), FILTER_SANITIZE_STRING);
                    $fetchData[] = array('tel_no' => $Phone,'camp_id'=>$idcampign,'status'=>$status,'status_new'=>$new_status);
                }              
               
                $data['employeeInfo'] = $fetchData;
                $this->import->setBatchImport($fetchData);
                $this->import->importData();
            } else {
                echo "Please import correct file";
            }
        }

        echo "  <script>
                    alert('Import Success');location.href= '".base_url()."cmsadmin/generat/gen_list/".$idcampign."';
                </script>";
        
    }
}
?>