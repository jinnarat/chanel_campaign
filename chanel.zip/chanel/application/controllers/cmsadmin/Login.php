<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
class Login extends DB_Controller {
	
	function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
		$this->load->model('Select_data');
		$this->load->model('Lists_model');	
    }
	
	function index(){
         
		$this->session->sess_destroy();
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$this->load->view('cmsadmin/Login/login', $data);
	}
	
	function check_login(){
		$username = $this->input->post('username');
        $password = $this->input->post('password');       
        $md5_password = sha1($this->input->post('password'));
		if(!empty($username) and !empty($password)){
            $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$md5_password' AND status = 'A'";
			$query = $this->db->query($sql);
			
			if($query->num_rows() > 0){
				$row = $query->row(); 
				if($row->end_expire < date('Y-m-d H:i:s') && ($row->expire_date != 'N')){
					echo 'expire';
					exit;
				}
                $menu_id = explode("," , $row->menu_id);
                $session = array(
                    'uicnid' => $row->id,    
                    'uicnname' => $row->name, 
                    'uicnauthorize' => $row->user_type,
                    'umenu_id'  => $menu_id
                );                
               
                $this->session->sess_expiration = '14400';// expires in 4 hours
                //delete_cookie('username');
                //delete_cookie('password');                    
               
                $this->session->set_userdata($session);
                echo 'ok'; //correct
            }else{
                echo 'fail'; //don't has any this user or wrong username/password
            }
		}
	}
	
	function logout(){		
        $this->session->sess_destroy();
        redirect('cmsadmin/login');
    }
	
}
