<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
ini_set('memory_limit', '1024M');
class Report extends DB_Controller {
	
	function __construct()
    {
        parent::__construct();
		$this->load->model('Select_data');
		$this->load->model('Lists_model');
		$chk_userlogin = $this->session->userdata('uicnname');
        if(!$chk_userlogin){
			redirect(URL_Login);
        }
    }
		
    function index(){
		$header['menu'] = 'about';
		$header['menu_sub'] = '';
		
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data['data_content'] = '';
		
		$this->load->view('cmsadmin/header', $header);
        $this->load->view('cmsadmin/mainpage', $data);  
		$this->load->view('cmsadmin/footer');
	}
	
	function camp_list(){
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data['id'] = "";
		$data['list_camp'] = "";
		$i = 1;
		$detail_id ="";
		
		
		$sql = $this->Select_data->select_data("* ,DATE_FORMAT(camp_start, '%d-%m-%Y %H:%i') as camp_start", "campaign", "AND status != 'D'")->result_array();
		if(count($sql) > 0){
			foreach($sql as $rs){
				$id = $rs['id'];
				$name = htmlspecialchars_decode(trim($rs['campname']), ENT_QUOTES);
				$main_url = htmlspecialchars_decode(trim($rs['main_url']), ENT_QUOTES);
				$start_date = strip_tags(htmlspecialchars_decode(trim($rs['camp_start']), ENT_QUOTES));
				$end_date = strip_tags(htmlspecialchars_decode(trim($rs['camp_end']), ENT_QUOTES));

				$data['list_camp'] .= "
					<tr>
						<td style='text-align: center;'>".$i."</td>
						<td style='text-align: left;'>".$name."</td>
						<td style=' text-align:left;'>".$start_date."</td>
						<td style=' text-align:center;'>
							<a href='".$data['uri']."cmsadmin/report/rep_list/".$id."'><span data-feather='edit'></span></a>
						</td>
						<td style=' text-align:center;'>
							<a href='javascript:void(0)' onclick='DelAction(".$id.");'><font color='red'><span data-feather='trash-2'></span></font></a>
						</td>
					</tr>";
                        
				$i++;
			}
		}else{
			$data['list_camp'] = "
				<tr>
					<td align='center' colspan='5'>ไม่มีข้อมูล</td>									
				</tr>";
		}
		
		$this->load->view('cmsadmin/header', $header);
        $this->load->view('cmsadmin/Report/camp_list', $data);  
		$this->load->view('cmsadmin/footer');
	}
	
	function rep_list($id = null,$detail_id = null){
		$data['uri'] = $this->Main_function->html_chars(base_url());

		$camp_id				= $id;
		$detail_id  			= $detail_id;

		$condition 	= '';
		$store_code = '';
		$store_name = '';
		$tel = '';
		$url = '';
		$dateStart = '';
		$dateEnd = '';
		
		$data['id'] = "";
		$data['data_list'] = "";
		$i = 1;

		$data['camp_id'] = $camp_id;
		$data['select_status'] = '';
		$data['dateStart']		= '';
		$data['dateEnd']	='';
		$data['code'] ='';
		$data['idcard']='';
		$data['name']='';

		$store_code		= htmlspecialchars($this->input->post('scode'),ENT_QUOTES);
		$store_name		= htmlspecialchars($this->input->post('sname'),ENT_QUOTES);
		$tel			= htmlspecialchars($this->input->post('tel'),ENT_QUOTES);
		$url			= htmlspecialchars($this->input->post('url'),ENT_QUOTES);
		$dateStart		= htmlspecialchars($this->input->post('dateStart'),ENT_QUOTES);
		$dateEnd		= htmlspecialchars($this->input->post('dateEnd'),ENT_QUOTES);
	
		$date_start	 = $this->Main_function->convert_data($dateStart,"dateToDB");
		$date_end	= $this->Main_function->convert_data($dateEnd,"dateToDB");

		if(!empty($date_start) && !empty($date_end)){
			$condition  .= "AND sms_no.url_start  BETWEEN '$date_start 00:00:00.000' AND '$date_end 23:59:59.000' AND sms_no.url_end  BETWEEN '$date_start 00:00:00.000' AND '$date_end 23:59:59.000' OR sms_no.url_end = '0000-00-00 00:00:00.000'";  
			$data['url_start']  =  $dateStart;
			$data['url_end'] =   $dateEnd;                                       
		}

		if(!empty($store_code)){
			$condition  .= "AND  store.shop_code LIKE '%$store_code%'";  
			$data['code']	= $store_code ;                                                                    
		}

		if(!empty($store_name)){
			$condition  .= "AND store.shop_name LIKE '%$store_name%'";  
			$data['store_name']	= $store_name ;                                                                    
		}
		if(!empty($tel)){
			$condition  .= "AND sms_no.tel_no LIKE '%$tel%'";  
			$data['tel_no']	= $tel ;                                                                    
		}

		if(!empty($url)){
			$condition  .= "AND campaign.main_url LIKE '%$url%' OR sms_no.url_gen LIKE '%$url%'";  
			$data['url']	= $url ;                                                                    
		}
			
			$name = $this->Select_data->select_data("campname", "campaign","AND id = '".$camp_id."' ")->result_array();
			if(count($name) > 0){
				foreach($name as $rd){
					$data['camp_name'] = htmlspecialchars_decode(trim($rd['campname']), ENT_QUOTES);
				}
			}

			$sql = $this->Select_data->report($camp_id, $condition)->result_array();
				if(count($sql) > 0){
					foreach($sql as $rd){
						$url_sent = htmlspecialchars_decode(trim($rd['url_gen']), ENT_QUOTES);


						$data['data_list'] .= "<tr>
										<td style='text-align: center;'>".$i."</td>
										<td style=' text-align:center;'>".htmlspecialchars_decode(trim($rd['campname']), ENT_QUOTES)."</td>
										<td style=' text-align:center;'>".htmlspecialchars_decode(trim($rd['tel_no']), ENT_QUOTES)."</td>
										<td style=' text-align:center;'>".htmlspecialchars_decode(trim($rd['url_start']), ENT_QUOTES)."</td>
										<td style=' text-align:center;'>".htmlspecialchars_decode(trim($rd['url_end']), ENT_QUOTES)."</td>
										<td style=' text-align:left;'>".URLFRONT.$url_sent."</td>
										<td style=' text-align:center;'>".htmlspecialchars_decode(trim($rd['shop_code']), ENT_QUOTES)."</td>
										<td style=' text-align:center;'>".htmlspecialchars_decode(trim($rd['shop_name']), ENT_QUOTES)."</td>
										
										</tr>";

						$i++;
					}
				
				}else{
					// $data['data_list'] = "
					// 	<tr>
					// 		<td align='center' colspan='8'>ไม่มีข้อมูล</td>									
					// 	</tr>";
				}
		
		$this->load->view('cmsadmin/header');
        $this->load->view('cmsadmin/Report/rep_list', $data);  
		$this->load->view('cmsadmin/footer');
	}

	function delete_camp()
	{
		$detail_id			= $this->input->post('id');
		$data['updateby'] 	= $this->session->userdata('uicnid');
		$data['update_date']	= date("Y-m-d H:i:s");	
		$data['status']= "D";
		$this->db->where('id', $detail_id);
		if($this->db->update('campaign', $data))
		{
			$result = "pass";				
		}else{
			$result = "fail";
		}
		echo $result;
	}

}
?>
