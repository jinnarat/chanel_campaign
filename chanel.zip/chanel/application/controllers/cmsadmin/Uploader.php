<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
class Uploader extends DB_Controller {	
	function __construct(){
        parent::__construct();
		$this->load->model('Lists_model');
    }	
	
	public function index(){	
		$allowed = array('png', 'jpg', 'gif', 'zip');
		// $path = '../uploads/f_others/';
		$pathFile = 'f_others/';
		
		$path   = PATHFRONTUPLOAD.$pathFile;  
		
		if (!file_exists($path)) {
			mkdir($path, 0777, true);
		}
		
		if(isset($_FILES['file']) && $_FILES['file']['error'] == 0){
			$extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
			if(!in_array(strtolower($extension), $allowed)){
				echo '{"status":"error"}';
				exit;
			}
			/* if(move_uploaded_file($_FILES['file']['tmp_name'], 'images/'.$_FILES['file']['name'])){
				$tmp = 'images/'.$_FILES['file']['name'];
				$new = '../images/'.$_FILES['file']['name']; //adapt path to your needs;
				if(copy($tmp, $new)){
				echo 'images/'.$_FILES['file']['name'];
				//echo '{"status":"success"}';
				}
				exit;
			} */
			
			$file_upload = $_FILES['file']['name'];
			$file_original	= $_FILES["file"]["name"];
			$file_size 		= $_FILES["file"]['size'];
			$ext_img 		= pathinfo($file_original, PATHINFO_EXTENSION);
			$file_name 		= "img_".date("YmHis").".".$ext_img;
			$file_path 		= $path.$file_name;
			if (file_exists($path.$file_original)) {
				$array_file = explode(".", $file_original);
				$file_upload = $array_file[0].'_'.date("YmHis").'.'.$ext_img;
			}
			// echo $path.$file_upload; exit;
			if(move_uploaded_file($_FILES['file']['tmp_name'],  $path.$file_upload)){
				// $tmp = 'images/'.$_FILES['file']['name'];
				// $new = '../'.PATHFRONTUPLOAD.'f_summernote/'.$_FILES['file']['name']; //adapt path to your needs;
				// $new = $path.$_FILES['file']['name']; //adapt path to your needs;
				// if(copy($tmp, $new)){
					// echo 'images/'.$_FILES['file']['name'];
					// echo URLFRONT.'upload_file/'.$file_upload;
					// echo 'http://192.168.16.130:8080/EECI/eeci/upload_file/';
					// echo URLFRONT.'upload_file/f_other/'; exit;
					echo URLFRONT.'uploads/f_others/'.$file_upload;
					
				// echo '{"status":"success"}';
				// }
				exit;
			}
		}
		echo '{"status":"error"}';
		exit;
	}
}
