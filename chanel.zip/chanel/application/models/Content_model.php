<?php

class Content_model extends CI_Model
{
    function __construct(){
        parent::__construct();
		
    }
	
	function select_data($field=null,$table=null,$campid=null,$pageno=null){
		$sql = "SELECT $field FROM $table WHERE camp_id = $campid AND page_no = $pageno";
		
		return $rs=$this->db->query($sql);
	} 

	function select_type($field=null,$table=null,$cond=null,$orderby=null,$sortby='asc'){
	
		$sql = "SELECT $field FROM $table WHERE 1 ";
		// $sql = "SELECT $field FROM $table WHERE ";
		
		if($cond != null || $cond != ''){
			$sql .= $cond;
		}
		
		if($orderby != null || $orderby != ''){
			$sql.= " ORDER BY $orderby $sortby ";
		}
	
		return $rs=$this->db->query($sql);		
	}

	function select_number($field=null,$table=null,$number=null,$camp_id=null){
		$sql = "SELECT $field FROM $table WHERE tel_no = $number AND camp_id = $camp_id";
		
		return $rs=$this->db->query($sql);
	}
	function insertdatetolog($table=null,$telno=null,$campid=null,$date=null,$status=null){
		$sqlin = "INSERT INTO $table (campid,tel_no,create_time,status) VALUES ($campid,$telno,'$date','$status')";

		return $rsi=$this->db->query($sqlin);
	}
	function updatedatetostart($table=null,$telno=null,$campid=null,$date=null){
		$sqlin = "UPDATE $table set url_start = '$date', status_new = 'Y' WHERE camp_id = $campid AND tel_no = $telno AND status_new = 'N'";

		return $rsi=$this->db->query($sqlin);
	}

	function updatedatetoend($table=null,$telno=null,$campid=null,$date=null){
		$sqlin = "UPDATE $table set url_end = '$date' WHERE camp_id = $campid AND tel_no = $telno";

		return $rsi=$this->db->query($sqlin);
	}

	function select_codeshop($field=null,$table=null,$telno=null,$campid=null){
		$sql = "SELECT $field FROM $table WHERE tel_no = '$telno' AND camp_id = '$campid'";
		
		return $rs=$this->db->query($sql);
	}

	function updatetoshopcode($table=null,$telno=null,$campid=null,$code=null){
		$sqlin = "UPDATE $table set status = '$code' WHERE camp_id = $campid AND tel_no = $telno";

		return $rsi=$this->db->query($sqlin);
	}

	function updatetoshop_code($table=null,$telno=null,$campid=null,$code=null){
		$sqlin = "UPDATE $table set shop_id = '$code' WHERE camp_id = $campid AND tel_no = $telno";

		return $rsi=$this->db->query($sqlin);
	}
	function updateproduct($table=null,$telno=null,$campid=null,$data=null){
		$sqlin = "UPDATE $table set product_id = '$data' WHERE camp_id = $campid AND tel_no = $telno";

		return $rsi=$this->db->query($sqlin);
	}

	function select_shopcode($field=null,$table=null,$code=null){
		$sqlb = "SELECT $field FROM $table WHERE shop_code = '$code'";

		return $rsi=$this->db->query($sqlb);
	}
	function select_gencode($field=null,$table=null,$gen_code=null){
		$sqlx = "SELECT $field FROM $table WHERE url_gen = '$gen_code'";
		
		return $rsa=$this->db->query($sqlx);
	}
	function select_i($field=null,$table=null,$campid=null,$pageno=null){
		$sql = "SELECT $field FROM $table WHERE camp_id = $campid AND page_no = $pageno AND NOT status = 'D'";
		
		return $rs = $this->db->query($sql);
	}
}
?>