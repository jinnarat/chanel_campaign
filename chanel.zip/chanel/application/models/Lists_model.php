<?php

class Lists_model extends CI_Model
{
    function __construct(){
        parent::__construct();
		
    }
	
	function select_data($field=null,$table=null,$cond=null,$orderby=null,$sortby='asc'){
		$sql = "SELECT $field FROM $table WHERE status != 'D' ";
		if($cond != null || $cond != ''){
			$sql .= $cond;
		}
		if($orderby != null || $orderby != ''){
			$sql.= " ORDER BY $orderby $sortby ";
		}
		return $rs=$this->db->query($sql);
	}
	function user_list($id=null)
	{
		$sql = "SELECT * FROM user WHERE status != 'D'";
		if($id != null || $id != '')
		{
			$sql .= " AND id = '".$id."'  ";
		}
		$sql .= " ORDER BY id desc";
		
		return $rs=$this->db->query($sql)->result_array();		
	}
	
}
?>