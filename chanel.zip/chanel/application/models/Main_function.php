<?php

class Main_function extends CI_Model
{
    function __construct(){
        parent::__construct();
    }
	
    function convertToTIS($string){
        return iconv("utf-8","tis-620//IGNORE",$string);
    }
	
    function convertToUTF($string){
        return iconv("tis-620","UTF-8//IGNORE",$string);
    }
	
	function getsBirthDate() {
		$result = "";
		for($i = 1; $i < 32; $i++){ $result .= '<option value="'.$i.'">'.$i.'</option>'; }
		return $result;
	}
	
	function getsBirthMonth($lang=null) {
		$result = "";
		for($i = 1; $i < 13; $i++){			
			if($lang == 'th'){
				$m = $this->Main_function->FullMonthTH($i);
			}else{
				$m = $this->Main_function->FullMonthEN($i);
			}
			$result .= '<option value="'.$i.'">'.$m.'</option>';
		}
		return $result;
	}	
	
	function getsBirthYear($type=null) {
		$now_year = date("Y");
		if($type != "" || $type != null){
			$now_year = date("Y")+543;
		}		
		$result = "";
		for($i = 0; $i < 100; $i++){
			$result .= '<option value="'.$now_year.'">'.$now_year.'</option>';
			$now_year--;
		}
		return $result;
	}
	
	function ShortDayTH($Day=null){
	  $sDay = array("Sun" => "อาทิตย์", "Mon" => "จันทร์", "Tue" => "อังคาร", "Wed" => "พุธ", "Thu" => "พฤหัสบดี", "Fri" => "ศุกร์", "Sat" => "เสาร์");
	  $result = $sDay[$Day];
	  return $result;
	}
	
	function ShortMonthTH($Month=null){
	  $sMonth = array("","ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.");
	  $result = $sMonth[$Month];
	  return $result;
	}
	
	function FullMonthTH($Month=null){
	  $sMonth = array("","มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฏาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม");
	  $result = $sMonth[$Month];
	  return $result;
	}
	
	function ShortMonthEN($Month=null){
	  $sMonth = array("","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec") ;
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function FullMonthEN($Month=null){
	  $sMonth = array("","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December") ;
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function FullMonthCH($Month=null){
	  $sMonth = array("","一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月") ;
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function FullMonthAll($Month=null, $lang=null){
		if($lang == "th"){
			$result = $this->Main_function->FullMonthTH($Month);
		}else{
			$result = $this->Main_function->FullMonthEN($Month);
		}
		return $result;
	}
	
	function getsNumericMonthEN($Month=null){
	  $sMonth = array("Jan" => "1", "Feb" => "2", "Mar" => "3", "Apr" => "4", "May" => "5", "Jun" => "6", "Jul" => "7", "Aug" => "8", "Sep" => "9", "Oct" => "10", "Nov" => "11", "Dec" => "12");
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function siteURL(){
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$domainName = $_SERVER['HTTP_HOST'];
		return $protocol.$domainName;
	}
	
	function DateThai($strDate){
		$strYear = date("Y",strtotime($strDate))+543;
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$strMonthThai=$strMonthCut[$strMonth];
		return "$strDay/$strMonth/$strYear";
	}
	
	function send_email($from=null, $email_to=null, $subject=null, $body=null, $bcc="monrudee.t@sundae.co.th"){		
		$user_id 	= $this->session->userdata('MEMID');
		
		$this->load->library('email');
		
		$config['protocol']    = 'smtp';
        $config['smtp_host']    = SMTPHOST;
        $config['smtp_port']    = SMTPPORT;
		//$config['smtp_crypto']    = 'tls';
        $config['smtp_timeout'] = '60';
        // $config['smtp_user']    = SMTPUSER;
        // $config['smtp_pass']    = SMTPPASSWORD;
        $config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
		//$config['crlf']    = "\r\n";
        $config['mailtype'] = 'html'; // or html
        $config['validation'] = TRUE; // bool whether to validate email or not      

        $this->email->initialize($config);
		
		$this->email->clear();
		$this->email->from('webinfo@eeci.or.th', 'EECi');
		$this->email->to($email_to);
		$this->email->bcc($bcc);
		$this->email->subject($subject);
		$this->email->message($body);
		
		if($this->email->send()){
			return true;
		}else{
			return false;
		}
		
		// echo $this->email->print_debugger();
	}
	
	function template_mail($subject=null, $body=null){
		$uri = base_url();

		$html = "";
		$html .= "<table align='center' width='100%' style='width: 100%;' border='0' cellspacing='0' cellpadding='0'>";
		$html .= "
			<tr height='15'></tr>
			<tr>
				<td width='10%'></td>
				<td width='80%' align='center'>
					<table  width='100%' style='width: 100%;' border='0' cellspacing='0' cellpadding='0'>
						<tr>
							<td width='300' align='left'>
								<img src='".$uri."/assets/images/logo_iTAP.png' height='48' />
							</td>
							<td align='right' valign='bottom' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px; font-weight: bold; text-align: right;color:#661f86;'>
								<span style='color:#661f86;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;line-height:30px;'>".$subject."</span>
							</td>
							<td width='20'></td>
						</tr>
					</table>
				</td>
				<td width='10%'></td>
			</tr>
			<tr height='7'><td width='100%' colspan='3'></td></tr>
			<tr height='1'><td width='100%' colspan='3' bgcolor='#808185'></td></tr>
			<tr height='20'></tr>
			<tr>
				<td width='100%' colspan='3' bgcolor='#eeeeee'>".$body."</td>
			</tr>
			<tr height='20'></tr>
			<tr>
				<td width='10%'></td>
				<td width='80%' align='center' bgcolor='#808185'>
					<table  width='100%' style='width: 100%;' border='0' cellspacing='0' cellpadding='0'>
						<tr height='30'></tr>
						<tr>
							<td width='4%'></td>
							<td width='30%' valign='top' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px;'>
								
							</td>
							<td width='30%' valign='top' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px;'>
								
							</td>
							<td width='30%' valign='top' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px;color:#ffffff;'>
							
							</td>
							<td width='4%'></td>
						</tr>
						<tr height='30'></tr>
					</table>
				</td>
				<td width='10%'></td>
			</tr>";
		$html .= "</table>";
				
		return $html;
	}
	
	function genRandomString($length=null) {
		//$length = 8;
		$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
		$string = '';    
		for ($p = 0; $p < $length; $p++) {
			$string .= $characters[mt_rand(0, strlen($characters))];
		}
		return $string;
	}
	
	function getsEdegCompany($value=null){
		$total = 90;
		if($value != null){
			for($i = 1; $i <= $value; $i++){
				$total = $total+3.6;
				// echo $i.' : '.$total.'<br />';
			}
		}
		return $total;		
	}
	
	function substr_desc($str, $start_p, $len_p) {
		$str_post = "";
		if(strlen($str) > $len_p){
			$str_post = "...";
		}
		return preg_replace( '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$start_p.'}'.
        '((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$len_p.'}).*#s',
        '$1' , $str ) . $str_post;
	}
	
	function getFileInfo($file, $mode){ 
		#mode : dirname = Directory Name, basename  = Filename, extension = Extension File 
		$path_parts = pathinfo($file); 
		return $path_parts[$mode]; 
	}
	
	function convString($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
	
	function match_introtext($text=null){
		$text = stripslashes($text);
		/* $result = trim(preg_match('/[\'!`. “"^?$%&*()}{@#~?><>,;|=_+?-]/', $text)); */
		$result = trim(preg_match('/[\'!`.“"^?$%&*()}{@#~?><>,;|=_+?]\"/', $text));
		return $result;
	}
	
	function replace_introtext($text=null){		
		$result = preg_replace("/[^a-z0-9\.,\_\-ก-ฮะาิีุูเะแำไใๆ่้๊๋ั็์ึื ]/i", "", trim($text));		
		return $result;
	}
	
	function html_chars($text=null){
		$result = htmlspecialchars(stripslashes(trim($text)), ENT_QUOTES);
		return $result;
	}

	function showMessage($mess, $url) {
		print "<script language = 'JavaScript'>\n";
		print "     mess = \"".$mess."\";\n";
		print "		alert(mess)\n";
		print "</script>\n";
		if ($url != "null") {
			print  "<meta http-equiv=\"refresh\" content=\"0;url=$url\">";
			exit;
		}
	}
	
	function showMessageThenBack($mess) {
		print "<script language = 'JavaScript'>\n";
		print "     mess = \"".$mess."\";\n";
		print "		alert(mess);	\n";
		print "		window.history.back();	\n";
		//print "		return false; \n";
		print "</script>\n";
		exit();
	}
	
	function DatePreview($strDate, $time=null){
		$strYear = date("Y",strtotime($strDate))+543;
		// $strYear = date("Y",strtotime($strDate));
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		// $strMonthCut = array("","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec") ;
		// $strMonthCut = array("","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December") ;
		$strMonthThai=$strMonthCut[$strMonth];
		$strTime = "";
		if($time != null || $time != ""){
			$strTime = $strHour.':'.$strMinute.':'.$strSeconds;
		}
		return "$strDay $strMonthThai $strYear $strTime";
	}
	
	function DateDecode($strDate){
		$strDate = explode(" ", $strDate);
		$strMonthNum = Array("ม.ค." => "1","ก.พ." => "2","มี.ค." => "3","เม.ย." => "4","พ.ค." => "5","มิ.ย." => "6","ก.ค." => "7","ส.ค." => "8","ก.ย." => "9","ต.ค." => "10","พ.ย." => "11","ธ.ค." => "12");
		if(count($strDate) > 0){
			$strYear = $strDate[2]-543;
			$strDay = $strDate[0];
			$strMonth = $strMonthNum[$strDate[1]];
		}
		// return "$strYear-$strMonth-$strDay ".date("H:i:s");
		return "$strYear-$strMonth-$strDay";
	}

	function genCodeUrl($length = null) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	function getsMenuHeader($uri=null){
		$uauth = $this->session->userdata('uicnauthorize');
		$umenu = $this->session->userdata('umenu_id');
		
		$result = "";
		
		if($uauth == "Admin" || in_array("1", $umenu)){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_camp" href="'.$uri.'cmsadmin/campaign/camp_list">
						<span data-feather="book-open"></span> Campaign
					</a>
				</li>';
		}
	
		if($uauth == "Admin" || in_array("2", $umenu)){

			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_report" href="'.$uri.'cmsadmin/generat/camp_list">
						<span data-feather="activity"></span> Generat URL
					</a>
				</li>';
		}
		if($uauth == "Admin" || in_array("3", $umenu)){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_report" href="'.$uri.'cmsadmin/report/camp_list">
						<span data-feather="list"></span> Report
					</a>
				</li>';
		}
		if($uauth == "Admin"){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_user" href="'.$uri.'cmsadmin/user/user_list">
						<span data-feather="users"></span> User Management
					</a>
				</li>';
		}
		
		return $result;
	}
	
	function addUserLog($info=null, $code=null, $table=null){
		$data['user_id'] 	= $this->session->userdata('uid');
		$data['name'] 	= $this->session->userdata('uname');
		$data['lastupdate'] = date("Y-m-d H:i:s");
		$data['action_info'] = $info;
		$data['action_url'] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$data['action_code'] = $code;
		$data['action_table'] = $table;
		$data['ip'] = $_SERVER['REMOTE_ADDR'];
		
		$result = "uid : ".$data['user_id']." uname : ".$data['name']." url : ".$data['action_url']." info : ".$data['action_info']." code : ".$data['action_code']." table : ".$data['action_table']." ip : ".$data['ip'];
		if($this->db->insert('user_log', $data))
		{
			//echo "pass";
			$result = "pass";
		}
		return $result;
	}

	public function convert_data($date=null,$format=null){
		if($date != ''){
		  $time = strtotime(str_replace("/" , "-", $date));
			if($format == 'time'){  
				$newformat = date('H:i',$time);
			}elseif($format == 'dateToDB'){
				$newformat = date('Y-m-d',$time); 
			}elseif($format == 'datetimeToDB'){
				$newformat = date('Y-m-d H:i:s',$time);
			}elseif($format == 'dateTobx'){
				$newformat = date('d M Y',$time);
			}elseif($format == 'dateTobx'){
				$newformat = date('d M Y',$time);
			}
			else{
			$newformat = date('d-m-Y',$time);
			}
			 return $newformat;
		}else{
		 return '';
		}
	}
	
}
?>