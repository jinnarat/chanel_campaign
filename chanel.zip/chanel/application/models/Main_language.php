<?php

class Main_language extends CI_Model
{
    function __construct(){
        parent::__construct();
		$this->load->model('Lists_model');
    }
	
	function setLanguage(){
		$uri = $this->Main_function->html_chars(base_url());
		$lang = 'th';
		// $lang = $this->uri->segment(1);
		
		$uri = $this->Main_function->html_chars(base_url());
		$segment = $this->uri->segment(1);
		if(($segment != null && $segment != "") && ($segment == "th" || $segment == "en")){
			$lang = $segment;
		}else{
			/* $text = $this->Main_function->html_chars($segment);
			if($text != ""){
				$check_lang = $this->Main_function->match_introtext($text);
				if($check_lang != 0){
					redirect(base_url().'th/', 'refresh');
				}
			}else{
				redirect(base_url().'th/', 'refresh');
			} */
			
			// redirect($uri.'th/', 'refresh');
		}
		
		$session = array(
			'LANG' => $lang
		);
		
		$this->session->sess_expiration = '14400';// expires in 4 hours
		$this->session->set_userdata($session);
		
		return $lang;
	}
	
	function getsLanguage($menu_type=null){
		$result = "";
		$segment_1 = 'th';
		$segment_2 = '';
		$active_th = '';
		$active_en = '';
		$link = '';
		$link_th = '';
		$link_en = '';
		$uri = $this->Main_function->html_chars(base_url());
		$check_ssion_lang = $this->session->userdata('LANG');
		$path_url = $this->Main_function->html_chars($_SERVER['REQUEST_URI']);
		$menu_type = $this->Main_function->html_chars($menu_type);
		
		$link .= $menu_type.'/';
		if($this->uri->segment(1)){
			$segment_1 = htmlspecialchars(trim($this->uri->segment(1)), ENT_QUOTES);
		}
		if($this->uri->segment(2)){
			$segment_2 = htmlspecialchars(trim($this->uri->segment(2)), ENT_QUOTES);
			$link .= $segment_2.'/';
		}
		if($this->uri->segment(3)){
			$segment_3 = htmlspecialchars(trim($this->uri->segment(3)), ENT_QUOTES);
			$link .= $segment_3.'/';
		}
		if($this->uri->segment(4)){
			$segment_4 = htmlspecialchars(trim($this->uri->segment(4)), ENT_QUOTES);
			$link .= $segment_4.'/';
		}
		
		/* if( ($segment_2 == "news-a-activities" && $segment_3 != "") ){
			$link = $segment_2.'/';
			$url_friendly = htmlspecialchars(trim($this->uri->segment(4)), ENT_QUOTES);
			$rs = $this->Lists_model->news(null, 'news-activity', $url_friendly, null, null)->result_array();
			$x = 0;
			if(count($rs) > 0){
				$link_th = $segment_3.'/'.$segment_4.'/';
				$link_en = $segment_3.'/'.$segment_4.'/';
				$link_ja = $segment_3.'/'.$segment_4.'/';
				$link_ch = $segment_3.'/'.$segment_4.'/';
				foreach($rs as $val){
					// echo $val['language'];
					if($val['language'] == 'th'){ 
						$link_th = $val['id'].'/'.$url_friendly.'/'; 
					}else if($val['language'] == 'en'){ 
						$link_en = $val['id'].'/'.$url_friendly.'/';
					}else if($val['language'] == 'ja'){
						$link_ja = $val['id'].'/'.$url_friendly.'/';
					}else if($val['language'] == 'ch'){
						$link_ch = $val['id'].'/'.$url_friendly.'/';
					}
				}
			}else{
				$link .= $segment_3.'/'.$segment_4.'/';
			}
		} */
		
		//$link = $path_url;		
		if($segment_1 == 'th'){ $active_th = 'active'; }
		if($segment_1 == 'en'){ $active_en = 'active'; }
		
		$result = '<a onclick="changeLang(\'th\', \''.$link.'\')" class="'.$active_th.'">TH</a>&nbsp;&nbsp;<a onclick="changeLang(\'en\', \''.$link.'\')" class="'.$active_en.'">EN</a>';
		
		// return $check_ssion_lang.' '.$path_url;
		return $result;
	}
	
	function getsMenu($menu=null, $lang=null){
		$result = "";
		
		$query = $this->Lists_model->seo_page($menu, null, $lang)->row_array();
		if(count($query) != 0){
			$result = htmlspecialchars_decode(trim($query['url_friendly'])).'/';
		}
		
		return $result;
	}
	
	function getsUrlFriendly($menu=null, $lang=null){
		$result = "";
		
		$query = $this->Lists_model->apply_itap($menu, $lang)->row_array();
		if(count($query) != 0){
			$result = htmlspecialchars_decode(trim($query['link_url']));
		}
		
		return $result;
	}
	
}
?>