<?php

class Select_data extends CI_Model{
	
    function __construct(){
        parent::__construct();
    }	
	
	function select_data($field=null,$table=null,$cond=null,$orderby=null,$sortby='asc'){
		$sql = "SELECT $field FROM $table WHERE status != 'D' ";
		
		if($cond != null || $cond != ''){
			$sql .= $cond;
		}
		
		if($orderby != null || $orderby != ''){
			$sql.= " ORDER BY $orderby $sortby ";
		}
		// echo $sql; 
		return $rs=$this->db->query($sql);		
	}

	function url_sent($id=null){
		$sql = "SELECT CONCAT(campaign.main_url, sms_no.url_gen) as url_gen ,campaign.campname FROM `sms_no` inner join campaign on sms_no.camp_id = campaign.id";
		if($id != null || $id != ""){
			$sql .= " AND sms_no.id = '".$id."' ";
		}
		return $rs=$this->db->query($sql);
	}

	function shop($id=null){
		$sql = "SELECT store.shop_name,store.shop_code FROM sms_no inner join store on sms_no.shop_id = store.shop_code";
		if($id != null || $id != ""){
			$sql .= " AND sms_no.id = '".$id."' ";
		}
		return $rs=$this->db->query($sql);
	}

	function url_export($id=null){
		$sql = "SELECT CONCAT(campaign.main_url, sms_no.url_gen) as url_gen , sms_no.tel_no FROM `sms_no` inner join campaign on sms_no.camp_id = campaign.id";
		if($id != null || $id != ""){
			$sql .= " AND sms_no.camp_id = '".$id."' ";
		}
		return $rs=$this->db->query($sql);
	}

	function report($id=null, $cond=null){
		$sql = "SELECT * ,dropdown_content.detail as name_list, CONCAT(campaign.main_url, sms_no.url_gen) as url_gen , DATE_FORMAT(url_start, '%d-%m-%Y %H:%i') as url_start, DATE_FORMAT(url_end, '%d-%m-%Y %H:%i') as url_end , DATE_FORMAT(camp_start, '%d-%m-%Y %H:%i') as camp_start FROM sms_no
						LEFT JOIN campaign ON (sms_no.camp_id = campaign.id)
						LEFT JOIN store ON (sms_no.shop_id = store.shop_code)
						LEFT JOIN dropdown_content ON (sms_no.product_id = dropdown_content.id) WHERE sms_no.status != 'D'";
		if($id != null || $id != ""){
			$sql .= " AND sms_no.camp_id = '".$id."' ";
		}

		if($cond != null || $cond != ''){
			$sql .= $cond;
		}
		return $rs=$this->db->query($sql);
	}


	function gallery($ref_id=null, $category=null){
		$sql = "SELECT file_name, file_path FROM upload_file WHERE 1 AND flag_status = 'A' ";
		if($ref_id != null || $ref_id != ""){
			$sql .= " AND ref_id = '".$ref_id."' ";
		}
		if($category != null || $category != ""){
			$sql .= " AND category = '".$category."' ";
		}
		$sql .= " Order by updatedate desc";
		return $rs=$this->db->query($sql);
	}
	
}
?>