

<div class="warp-content">
	<div class="container">
		<div class="row">
			<div class="bg-page">
					<div class="text-center">
						<img src="<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>" class="img-size" />
					</div>
					<div class="innerbox-text text-center">
						<form id="form1"  name="form1" action="<?php echo base_url();?>content/checkcodeshop" method="post" onsubmit="return ischeckinput();">
							<?php echo $detail?>
							<p class="check-code"><b>สำหรับพนักงาน</b></p>
							<?php if($data_dropdown != ''){ ?>
								<div class="dropdrown-box">
									<select id="select_product" name="select_product" class="form-control dropdrown-input" onclick="select_data()">
										<option value="">-- กรุณาเลือก --</option>
											<?php echo $data_dropdown; ?>
									</select>
								</div>
								<div id="drop_alert" ></div><br>
							<?php } ?>
							<div class="box-control">
								<div class="box-row">
									<input type="text"class="form-control box-input numberic" placeholder="Shop Code" name="code" id="code" maxlength="3" autocomplete="off" onkeypress="return isInputNumber(event)">
								</div>
							</div>
							<div id="msg_alert" ></div><br>
								<a class="bth-code form1-submit" href="javascript:void(0)" >SUBMIT</a>
						</form>
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>

<script language=Javascript>
	$(document).ready( function() {
		$(document).on("keyup", ".numberic", function(){
			this.value = this.value.replace(/[^0-9]/g, '');
		})
	});

	$(document).on("click", "#form1 a.form1-submit", function(){
		$("#form1").submit();
	})

	function isInputNumber(evt){
		$('#msg_alert').hide();
	}
	
	function select_data(){;
		$('#drop_alert').hide();
	}
	
	function ischeckinput(){
		if($('#select_product').val() == ""){
			$('#drop_alert').empty().text('กรุณาเลือกผลิตภัณฑ์').show();
			return false;
		}else{
			$('#drop_alert').hide();
		}

		if($('#code').val() == ""){
			$('#msg_alert').empty().text('กรุณากรอกรหัสสาขา').show();
			return false;
		}else if(isNaN(document.form1.code.value)){
			$('#msg_alert').empty().text('กรุณากรอกข้อมูลที่เป็นตัวเลขเท่านั้น').show();
			return false;
		}else if(document.form1.code.value.length<3){
			$('#msg_alert').empty().text('กรุณากรอกข้อมูลให้ครบถ้วน').show();
			return false;
		}else{
			$('#msg_alert').hide();
		}
	}
            
 </script>
