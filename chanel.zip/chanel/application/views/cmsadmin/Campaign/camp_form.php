
<div class="page-header breadcamp"><?php echo anchor('cmsadmin/campaign/camp_list','Campaign')." > ".$text_action?></div>	
<div style="padding:7px 7px 7px 0;">
	<a href="<?php echo base_url()?>cmsadmin/campaign/page_lists/<?php echo $camp_id?>"><button class="btn btn-secondary btn-sm" type="button" ><span data-feather="arrow-left-circle"></span> กลับ</button></a>		
</div>
<form class="needs-validation card p-2 bg-light" name="form1" novalidate enctype="multipart/form-data" onsubmit="return chkForm();" method="post" action="<?php echo base_url()?>cmsadmin/campaign/update_content">
	<input type="hidden" name="camp_id" id="camp_id" value="<?php echo $camp_id?>">
	<input type="hidden" name="detail_id" id="detail_id" value="<?php echo $detail_id?>">
	<div class="card">
		<div class="row">
			<div class="col-md-6">
				<div class="card-group">
					<div class="card-body row">
						<div class="col-md-3" style="padding-right:0px">
							<span class="card-title star-require">Upload image</span>
						</div>
						<div class="col-md-9" style="padding-left:30px;">
							<input class="form-control" id="inputImg" type="file" name="inputImg" accept=".jpg,.gif,.png" multiple style="width:80%;display: inline-block;margin: 0 15px 0 0;">
							<!-- <font color='red' size="2"><p>* อัพโหลดไฟล์ jpg,gif,png ขนาดรูปไม่เกิน 512 KB และ ขนาดไม่น้อยกว่า 500*300 px</p></font> -->
						</div>
					</div>	
				</div>
				<?php if($detail_id !='0' && $detail_id != "" && $img_name != ""){ ?>
				<div class="card-group">
					<div class="card-body row">
						<div class="col-md-5" style="padding-left:30px">
							<img src="<?php echo PATH_IMG; ?>f_content/<?php echo $img_name; ?>" class="img-thumbnail" width="600"  height="200">
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
			<div class="col-md-6">
				<div class="card-group">
					<div class="card-body row">
						<div class="col-md-4" style="padding-right:0px">
							<span class="card-title">Upload button image</span>
						</div>
						<div class="col-md-8" style="padding-left:30px;">
							<input class="form-control" id="inputBtn" type="file" name="inputBtn" accept=".jpg,.gif,.png" multiple style="width:80%;display: inline-block;margin: 0 15px 0 0;">
							<!-- <font color='red' size="2"><p>* อัพโหลดไฟล์ jpg,gif,png ขนาดรูปไม่เกิน 512 KB และ ขนาดไม่น้อยกว่า 500*300 px</p></font> -->
						</div>
					</div>	
				</div>
				<?php if($detail_id !='0' && $detail_id != "" && $img_btn != ""){ ?>
				<div class="card-group">
					<div class="card-body row">
						<div class="col-md-5" style="padding-left:30px">
							<img src="<?php echo PATH_IMG; ?>f_content/<?php echo $img_btn; ?>"class="img-thumbnail" width="600"  height="200">
						</div>
					</div>
				</div>
				<?php } ?>

			</div>
		
		</div>

		<div class="card-group">
			<div class="card-body" >
				<span class="card-title">Detail</span>
				<textarea class="form-control summernote-Image" name="detail" id="detail"><?php echo $detail; ?></textarea>		
				<div class="invalid-feedback">
					กรุณากรอกข้อมูล Detail
				</div>			
			</div>
		</div>	
		<div class="row">
			<div class="col-md-4">
				<div class ="card-body row">
					<div class="col-md-3">
						<label for="agd_session" class="star-require">Status</label>
					</div>
					<div class="col-md-9">
						<select class="form-control form-control-sm" required id="status" name="status" onchange="SelectSession(this)">
							<option value="">-- กรุณาเลือก --</option>
							<option value="A" <?php if($status == "A") echo 'selected'; ?>>   Active   </option>
							<option value="I" <?php if($status == "I") echo 'selected'; ?>>   InActive   </option>
						</select>
						<div class="invalid-feedback">
							กรุณากรอกเลือก Status
						</div>
						<input type="text" class="form-control form-control-sm" id="agd_session_add" name="agd_session_add" placeholder="" value="" style="margin-top:7px;display:none";>				
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class ="card-body row">
					<div class="col-md-6">
						<label for="agd_session" class="star-require">Page no.</label>
					</div>
					<div class="col-md-6">
					<input class="form-control" id="page_no" maxlength="2" value="<?php echo $page_no; ?>" name="page_no" type="text" style="display: inline-block;" required>	
					</div>
				</div>
			</div>
			<div class="col-md-5">
				<div class ="card-body row">
					<div class="col-md-5">
						<label for="agd_session">Code background-color</label>
					</div>
					<div class="col-md-4">
					<input class="form-control" id="code_bg" maxlength="7" value="<?php echo $code_bg; ?>" name="code_bg" type="text" style="display: inline-block;">	
					</div>
				</div>
			</div>
		</div>	
	</div>

	<hr class="mb-4">	
	<div>
		<button class="btn btn-primary btn-sm" type="submit">บันทึก</button>		
	</div>
</form>


<script> 
	// Example starter JavaScript for disabling form submissions if there are invalid fields
	(function() {
		'use strict';

		window.addEventListener('load', function() { 
			// Fetch all the forms we want to apply custom Bootstrap validation styles to
			var forms = document.getElementsByClassName('needs-validation');

			// Loop over them and prevent submission
			var validation = Array.prototype.filter.call(forms, function(form) {
				form.addEventListener('submit', function(event) {
					if (form.checkValidity() === false) {
						event.preventDefault();
						event.stopPropagation();
					}
				form.classList.add('was-validated');
				}, false);
			});
		}, false);
	})();
  
	$('document').ready(function(){ 	
		$('.summernote').summernote({
			height: 100,
			tabsize: 2,			
			toolbar: [
				['style', ['style']], // no style button
				['style', ['bold', 'italic', 'underline']], //, 'clear'
				['fontsize', ['fontsize']],
				['color', ['color']],				
				['para', ['ul', 'ol', 'paragraph']],
				['codeview', ['codeview']]
				//['height', ['height']],
				//['insert', ['picture']], //, 'link'  no insert buttons
				//['table', ['table']], // no table button				
				//['help', ['help']] //no help button
			  ]
		});
	
    }); 

	$('.summernote-Image').summernote({
		height: 180,
		tabsize: 2,			
		toolbar: [
			['style', ['style']], // no style button
			['style', ['bold', 'italic', 'underline']], //, 'clear'
			['fontsize', ['fontsize']],
			['color', ['color']],				
			['para', ['ul', 'ol', 'paragraph']],
			['insert', ['link', 'picture']], //, 'link'  no insert buttons
			['insert',['video','media','hr']], //insert vdo
			['table', ['table']],
			['codeview', ['codeview']]
		],
		callbacks: {
			onImageUpload: function(files) {
				url = $(this).data('upload');
				sendFile(files[0], url, $(this));
			}
		},
		onCreateLink: function (url) {
			var email = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
			var phone = /^\+?[\d()-,.]+/
			var schemed = /^[a-z]+:/i
			url = url.trim();
			if (email.test(url)) {
				url = 'mailto:' + url;
			} else if (phone.test(url)) {
						url = 'tel:' + url.replace(/[ ().\-]/g,'');
			} else if (!schemed.test(url)) {
				url = 'http://' + url;
			}
			return url;
		}
	});

	function sendFile(file,editor,welEditable) {
		data = new FormData();
		data.append("file", file);

		$.ajax({
			url: "<?php echo base_url(); ?>cmsadmin/uploader/",
			data: data,
			cache: false,
			contentType: false,
			processData: false,
			type: 'POST',
			success: function(data){
				//$(welEditable).summernote("insertImage", data, 'filename');
				$(welEditable).summernote('insertImage', data, function ($image) {
					$image.addClass('img-responsive');
				});
			},
			error: function(jqXHR, textStatus, errorThrown) {
				console.log(textStatus+" "+errorThrown);
			}
		});
	}
	
	function SelectSession(obj)
	{
		if(obj.value == "ADD")
		{
			$("#agd_session_add").show();
		}else{
			$("#agd_session_add").val("");
			$("#agd_session_add").hide();
		}
	}
</script>