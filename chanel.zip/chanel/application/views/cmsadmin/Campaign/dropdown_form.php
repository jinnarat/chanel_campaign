
<div class="page-header breadcamp"><?php echo anchor('cmsadmin/campaign/camp_list','Campaign')." > ".$text_action?></div>	
<div style="padding:7px 7px 7px 0;">
	<a href="<?php echo base_url()?>cmsadmin/campaign/page_lists/<?php echo $camp_id?>"><button class="btn btn-secondary btn-sm" type="button" ><span data-feather="arrow-left-circle"></span> กลับ</button></a>		
</div>
<form class="needs-validation card p-2 bg-light" name="form1" novalidate enctype="multipart/form-data" onsubmit="return chkForm();" method="post" action="<?php echo base_url()?>cmsadmin/campaign/update_droplist">
	<input type="hidden" name="camp_id" id="camp_id" value="<?php echo $camp_id?>">
	<input type="hidden" name="list_id" id="list_id" value="<?php echo $list_id?>">
	<div class="card">
        <div class ="card-body row">
            <div class="col-md-1">
                <label for="agd_session" class="star-require">ข้อความ</label>
            </div>
            <div class="col-md-9">
            <input class="form-control" id="dropdown_text" maxlength="50" value="<?php echo $dropdown_text; ?>" name="dropdown_text" type="text" style="display: inline-block;" required>	
            </div>
        </div>	
	</div>
	<hr class="mb-4">	
	<div>
		<button class="btn btn-primary btn-sm" type="submit">บันทึก</button>		
	</div>
</form>