
<div class="page-header breadcamp"><?php echo anchor('cmsadmin/campaign/camp_list','Campaign')." > ".$text_action1?></div>	
<div style="padding:7px 7px 7px 0;">
	<a href="<?php echo base_url()?>cmsadmin/campaign/camp_list"><button class="btn btn-secondary btn-sm" type="button" ><span data-feather="arrow-left-circle"></span> กลับ</button></a>		
</div>
<?php echo form_open_multipart('cmsadmin/campaign/update_campaign', array('onsubmit' => 'return checkValidateSubject();'));?>
<div class="card">	
	<div class="card-header">
		<table width="100%">
			<tr>
				<td width="50%">หัวเรื่อง (ชื่อกิจกรรม วันเวลา) </td>
			</tr>
		</table>
	</div>
	<div class="card-body" id="div_input_topic">		
		<input type="hidden" name="input_id" id="input_id" value="<?php echo $camp_id?>">
			<div class="card">
				<div class="card-group row" >
					<div class="col-md-6">
						<div class="row">
							<div class="card-body">
								<span class="card-title star-require">Main URL</span><br>
								<div class="row">
									<div class="col-md-5">
										<span>&nbsp;&nbsp;http://chanelbeautyth.com/</span>	
									</div>
									<div class="col-md-7" style="padding-left: 0;">
										<input class="form-control form-control-sm" required type="text" id="Domain" name="Domain" value="<?php echo $main_url; ?>" />		
										<div class="invalid-feedback">
											กรุณากรอกข้อมูล Main URL
										</div>
									</div>
								</div>		
							</div>	
						</div>	
					</div>	
					<div class="col-md-6">
						<div class="row">
							<div class="card-body">
								<span class="card-title star-require">ชื่อกิจกรรม</span>
								<input class="form-control form-control-sm" required type="text" id="topic" name="topic" value="<?php echo $name; ?>" />		
								<div class="invalid-feedback">
									กรุณากรอกข้อมูลชื่อกิจกรรม
								</div>			
							</div>	
						</div>	
					</div>	
				</div>

				<div class="row"> 
					<div class="col-md-4">
						<div class ="card-body row">
							<div class="col-md-5" style="padding-left: 7px;">
								<label for="status" class="star-require">วันที่เริ่มกิจกรรม</label>
							</div>
							<div class="col-md-7" style="padding-left:30px">
								<input class="form-control" type="text" id="dateStart" name="dateStart" value="<?php echo $start_date; ?>" placeholder="Select Date" style="width:200px; text-align:center;" readonly="true" />
								<div class="invalid-feedback">กรุณากรอกเลือก วันที่เริ่มกิจกรรม</div>		
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class ="card-body row">
							<div class="col-md-5" style="padding-left: 7px;">
								<label for="status" class="star-require">วันสิ้นสุดกิจกรรม</label>
							</div>
							<div class="col-md-7" style="padding-left:30px">
								<input class="form-control" type="text" id="dateEnd" name="dateEnd" value="<?php echo $end_date; ?>" placeholder="Select Date" style="width:200px; text-align:center;" readonly="true" />
								<div class="invalid-feedback">กรุณากรอกเลือก วันสิ้นสุดกิจกรรม</div>		
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class ="card-body row">
							<div class="col-md-5">
								<label for="agd_session" class="star-require">รูปแบบการแสดง</label>
							</div>
							<div class="col-md-7">
								<select class="form-control" id="type" name="type" required>
									<option value="">-- กรุณาเลือก --</option>
									<option value="N" <?php if($type == "N") echo 'selected'; ?>>Normal</option>
									<option value="S" <?php if($type == "S") echo 'selected'; ?>>Slider</option>
								</select>
								<div class="invalid-feedback">
									กรุณาเลือกข้อมูล รูปแบบการแสดง
								</div>	
							</div>
						</div>
					</div>

				</div>
				<div class ="card-body">
					<input type="hidden" name="check_box" id="check_box" value="<?php echo $select_product?>">
					<span>&nbsp;&nbsp;</span>
					<input type="checkbox" class="form-check-input" id="exampleCheck" name="exampleCheck" value="" onclick="checkDropdown()">
					<label class="form-check-label star-require" for="exampleCheck">dropdown เลือกประเภทสินค้า</label>
				</div>
				<div class="card" id="selelect_list" style="display:none;">
					<div class ="card-body">
						<div>
							<a class="btn btn-info btn-sm" href="<?php echo base_url()?>cmsadmin/campaign/dropdown_form/<?php echo $camp_id?>" role="button">+ เพิ่มข้อมูล List</a>
						</div>
						<br>
						<div class="table-responsive">
							<table class="table table-striped table-sm"  style="text-align: center;">
								<thead>
									<tr>
									<th width="10%">ลำดับที่</th>
									<th width="60%">รายละเอียด</th>	
									<th width="10%"></th>
									<th width="10%"></th>
									</tr>
								</thead>
								<tbody id="tbody_camp">
									<?php echo $dropdown_list?>
								</tbody>
							</table>
						</div>
					
					</div>
					
				</div>

			</div>

		<div class="separate10"></div>		
		<button class="btn btn-primary btn-sm" type="submit" >บันทึก</button>		
	</div>	
</div>

<?php echo form_close(); ?>


<div class="separate10"></div>
<div align="">
	<?php if($camp_id == "")
		{			
	?>
		<span class="text-muted">คุณต้องกรอกข้อมูลในส่วนของ หัวเรื่อง (ชื่อกิจกรรม วันเวลา)  เป็นอันดับแรก</span>
	<?php	
		}else{
	?>
		<a class="btn btn-info btn-sm" href="<?php echo base_url()?>cmsadmin/campaign/camp_form/<?php echo $camp_id?>" role="button">+ เพิ่มข้อมูล</a>	
	<?php	
		}
	?>
</div> 
<br>
		<div class="table-responsive">
			<table class="table table-striped table-sm"  style="text-align: center;">
				<thead>
					<tr>
					<th width="10%">ลำดับที่</th>
					<th width="20%">รูปภาพ</th>
					<th width="60%">รายละเอียด</th>	
					<th width="10%"></th>
					<th width="10%"></th>
					<th width="10%"></th>
					</tr>
				</thead>
				<tbody id="tbody_camp">
					<?php echo $list_data?>
				</tbody>
			</table>
		</div>

<!-- <link rel="stylesheet" href="<?php echo $this->Main_function->html_chars(base_url()); ?>assets/css/jquery.ui.css?v=021419" /> -->
<style>.ui-datepicker {width: 200px;font-size: 14px;}</style>
<script type="text/javascript" src="<?php echo $this->Main_function->html_chars(base_url()); ?>assets/js/jquery-ui.min.js?v=021419"></script>

<link rel="stylesheet" media="all" type="text/css" href="<?php echo base_url()?>assets/js/jquerydatepicker/jquery-ui.css?v=<?php echo date("YmdHis")?>" />
<link rel="stylesheet" media="all" type="text/css" href="<?php echo base_url()?>assets/js/jquerydatepicker/jquery-ui-timepicker-addon.css?v=<?php echo date("YmdHis")?>" />

<script type="text/javascript" src="<?php echo $this->Main_function->html_chars(base_url()); ?>assets/js/jquerydatepicker/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo $this->Main_function->html_chars(base_url()); ?>assets/js/jquerydatepicker/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="<?php echo $this->Main_function->html_chars(base_url()); ?>assets/js/jquerydatepicker/jquery-ui-sliderAccess.js"></script>

<script> 
	
	$('document').ready(function(){ 

		var check_box = document.getElementById("check_box").value;
		
		if(check_box == 'Y'){
			$("#exampleCheck").prop("checked", true);
			$("#selelect_list").css("display", "inline");
		}else{
			$("#exampleCheck").prop("checked", false);
		}
		
		
		$('.summernote').summernote({
			height: 100,
			tabsize: 2,			
			toolbar: [
				['style', ['style']], // no style button
				['style', ['bold', 'italic', 'underline']], //, 'clear'
				['fontsize', ['fontsize']],
				['color', ['color']],				
				['para', ['ul', 'ol', 'paragraph']],
				['codeview', ['codeview']]
			  ]
		});
	
    }); 

	function checkDropdown(){
		var checkbox = $('#exampleCheck').is(":checked")

		if(checkbox == true){
			$("#exampleCheck").val("Y");
			$("#selelect_list").css("display", "inline");
		}else{
			$("#exampleCheck").val("N");
			$("#selelect_list").css("display", "none");
		}
	}
		
	
	function ClickAction()
	{		
		if($("#div_input_topic").css('display') === 'none') 
		{
			$("#btn_action").html("Hide");
			$("#div_input_topic").show();
		}else{
			$("#btn_action").html("Show");
			$("#div_input_topic").hide();
		}
	}
	
	function delect(id,camp_id)
	{		
		// console.log(id,camp_id); return false;
		
		if (confirm("Are you sure you want to delete?")) {
			$.ajax({
				data: "id=" + id,
				method: "post",
				url: "<?php echo base_url('cmsadmin/campaign/delete_data') ?>"
			}).done(function(e) {
				e = $.trim(e);
				if(e == 'pass'){
					alert('Delete data already.'); location.href='<?php echo base_url('cmsadmin/campaign/page_lists/') ?>'+camp_id;
				}
			})
		}
	}

	function delectList(id,camp_id)
	{		
		if (confirm("Are you sure you want to delete?")) {
			$.ajax({
				data: "id=" + id,
				method: "post",
				url: "<?php echo base_url('cmsadmin/campaign/delete_droplist') ?>"
			}).done(function(e) {
				e = $.trim(e);
				if(e == 'pass'){
					alert('Delete data already.'); location.href='<?php echo base_url('cmsadmin/campaign/page_lists/') ?>'+camp_id;
				}
			})
		}
	}
	
	function checkValidateSubject()
	{
		var camp_id	= $("#input_id").val();
		var subject 	= $("#input_subject").val();
		
		if(subject == "" || subject == "<p><br></p>")
		{
			$(".invalid-feedback").show();
			//$("#AlertModal").modal('show');
			//$("#AlertModal .modal-body").html('กรุณาใส่ข้อมูล หัวเรื่อง (ชื่อกิจกรรม วันเวลา สถานที่จัดงาน)');
			return false;
		}
		
		return true;
	}

	$(function(){
		var startDateTextBox = $('#dateStart');
		var endDateTextBox = $('#dateEnd'); 
		
		startDateTextBox.datepicker({ 
			dateFormat: 'dd M yy',
			onClose: function(dateText, inst) {
				if (endDateTextBox.val() != '') {
					var testStartDate = startDateTextBox.datetimepicker('getDate');
					var testEndDate = endDateTextBox.datetimepicker('getDate');
					if (testStartDate > testEndDate)
						endDateTextBox.datetimepicker('setDate', testStartDate);
				}
				else {
					endDateTextBox.val(dateText);
				}
			},
			onSelect: function (selectedDateTime){
				endDateTextBox.datetimepicker('option', 'minDate', startDateTextBox.datetimepicker('getDate') );
			}
		});

		endDateTextBox.datepicker({ 
			dateFormat: 'dd M yy',
			onClose: function(dateText, inst) {
				if (startDateTextBox.val() != '') {
					var testStartDate = startDateTextBox.datetimepicker('getDate');
					var testEndDate = endDateTextBox.datetimepicker('getDate');
					if (testStartDate > testEndDate)
						startDateTextBox.datetimepicker('setDate', testEndDate);
				}
				else {
					// startDateTextBox.val(dateText);
				}
			},
			onSelect: function (selectedDateTime){
				startDateTextBox.datetimepicker('option', 'maxDate', endDateTextBox.datetimepicker('getDate') );
			}
		});

	});
	
	
</script>