<div class="page-header breadcamp">
	Generat URL
</div> 
<br>
<div class="table-responsive">
	<table class="table table-striped table-sm">
		<thead>
			<tr>
			<th width="15%" style="text-align: center;">ลำดับ</th>
			  <th width="50%">ชื่อกิจกรรม</th>
			  <th width="30%">วันที่เริ่มกิจกรรม</th>
			  <th width="10%"></th>
			  <th width="10%"></th>
			</tr>
		</thead>
		<tbody id="tbody_camp">
			<?php echo $list_camp?>
		</tbody>
	</table>
</div>

<script>
	
	function ClickAction()
	{		
		if($("#div_input_topic").css('display') === 'none') 
		{
			$("#btn_action").html("Hide");
			$("#div_input_topic").show();
		}else{
			$("#btn_action").html("Show");
			$("#div_input_topic").hide();
		}
	}
	
	function DelAction(id)
	{		
		console.log(id);
		
		if (confirm("Are you sure you want to delete?")) {
			$.ajax({
				data: "id=" + id ,
				method: "post",
				url: "<?php echo base_url('cmsadmin/generat/delete_camp') ?>"
			}).done(function(e) {
				console.log(e);
				e = $.trim(e);
				if(e == 'pass'){
					alert('Delete data already.'); window.location.href='<?php echo base_url();?>cmsadmin/generat/camp_list';
				}
			})
		}
	}
	
	function checkValidateSubject()
	{
		var subject_id	= $("#input_subject_id").val();
		var subject 	= $("#input_subject").val();
		
		if(subject == "" || subject == "<p><br></p>")
		{
			$(".invalid-feedback").show();
			//$("#AlertModal").modal('show');
			//$("#AlertModal .modal-body").html('กรุณาใส่ข้อมูล หัวเรื่อง (ชื่อกิจกรรม วันเวลา)');
			return false;
		}
		
		return true;
	}
	
	
</script>