<div class="page-header breadcamp"><?php echo anchor('cmsadmin/generat/camp_list','Campaign')." > ".$camp_name." > Generat URL"?></div>	
<div style="padding:7px 7px 7px 0;">
	<a href="<?php echo base_url()?>cmsadmin/generat/camp_list"><button class="btn btn-secondary btn-sm" type="button" ><span data-feather="arrow-left-circle"></span> กลับ</button></a>		
</div>

 <br/><br/>

<div class="row">
		<!-- <?php if(isset($_GET['alert'])){
		echo "<div class=\"alert alert-success alert-dismissible fade show\" role=\"alert\">
		<strong>Import Success
		<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
		  <span aria-hidden=\"true\">&times;</span>
		</button>
	  </div>";
		}?>          
    </div> -->
	
</div>

<div class ="row">
	<?php //echo $camp_id; exit; ?>
	<div class="col-md-4">
	<?php

		$output = '';
		$output .= form_open_multipart('cmsadmin/import_excel/save');
		$output .= '<div class="row">';
		$output .= '<div class="col-10 "><div class="form-group">';
		// $output .= form_label('Import Lawyers', 'image');
		$uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
		// $uri_segments = explode('/', $uri_path);
		$output .= '<input value="'.$camp_id.'" name="idcampign" id="idcampign" type="hidden" >';
		$output .= '<input value="N" name="status" id="status" type="hidden" >';
		$output .= '<input value="N" name="new_status" id="new_status" type="hidden" >';
		$data = array(
			'name' => 'userfile',
			'id' => 'userfile',
			'class' => 'form-control filestyle',
			'value' => '',
			'data-icon' => 'false'
		);
		$output .= form_upload($data);
		$output .= '</div> <span style="color:red;">*Please choose an Excel file(.xls or .xlsx) as Input</span></div>';
		$output .= '<div class="col-2"><div class="form-group ">';
		$data = array(
			'name' => 'importfile',
			'id' => 'importfile-id',
			'class' => 'btn btn-info btn-sm',
			'value' => 'Import',
		);
		$output .= form_submit($data, 'Import Data');
		$output .= '</div>		
		</div></div>';
		$output .= form_close();
		echo $output;
?>

	</div>
	<div class = "col-md-5">
		
		<form  name="form2" novalidate enctype="multipart/form-data" onsubmit="return chkForm();" method="post" action="<?php echo base_url()?>cmsadmin/generat/update_phone">
		<input type="hidden" name="camp_id" id="camp_id" value="<?php echo $camp_id?>">
			<div class="row">
				<div class="col-md-4" style="padding-left: 35px;padding-right: 0;">
					Mobile Number
				</div>
				<div class="col-md-6">
					<input type="text" class="form-control form-control-md" id="phone" name="phone" placeholder="" value="" maxlength="10">	
				</div>
				<div class="col-md-2">
					<button class="btn btn-info btn-sm" type="submit">save</button>
				</div>	
			</div>	
		</from>
		
	</div>
	
	<div class = "col-md-2" style="float: right;">
		<a class="btn btn-info btn-sm"  href="<?php echo $uri; ?>cmsadmin/generat/url_update/<?php echo $camp_id?>" role="button">Gen URL</a>
	</div>
	<div class = "col-md-1">
		<button class= "btn btn-info btn-sm" style="float: right;margin-left: 15px;" onclick="exportDocument(<?php echo $camp_id?>);">Export Excel</button>
	</div>
</div>
<br>
<div class="table-responsive"> <br>
	<table class="table table-striped table-sm" id="myTable">
		<thead>
			<tr>
				<th width="10%" style="text-align: center;" >ลำดับ</th>
				<th width="15%" style="text-align: left">เบอร์โทรศัพท์</th>
				<th width="60%" style="text-align: center">URL</th>
				<th width="1%" style="text-align:right;" ></th>
				<th width="10%" style="text-align:center;">ลบ</th>
			</tr>
		</thead>
		<tbody id="tbody_activity">
			<?php echo $data_list ?>
		</tbody>
	</table>
</div>

<script>
	$('document').ready(function(){
		$('#myTable').DataTable({
			"dom": '<"top"fl>rt<"bottom"p><"clear">',
			"language": {
				"lengthMenu": "Display _MENU_ Records per page",
				"zeroRecords": "No record found",
				"info": "Display _START_ to _END_ of _TOTAL_ Records",
				"infoEmpty": "No records available",
				"infoFiltered": "(filtered from _MAX_ total records)"
			},
			"lengthMenu": [[25, 50, 100, 500], [25, 50, 100, 500]],
		});
	});

	function DelAction(id){  
		// console.log(id); return false;
		var camp_id = $("#idcampign").val()
		
		if (confirm("Are you sure you want to delete?")) {
			$.ajax({
				data: "id=" + id,
				method: "post",
				url: "<?php echo base_url('cmsadmin/generat/delete_data') ?>"
			}).done(function(e) {
				e = $.trim(e);
				if(e == 'pass'){
					 alert('Delete data already.'); location.href='<?php echo base_url('cmsadmin/generat/gen_list/') ?>'+camp_id;
				}
			});
		}
	}


	function exportDocument(id){
		
		var status  = $('#status').val();
		var dateStart = $('#dateStart').val();
		var dateEnd = $('#dateEnd').val();
		var scode = $('#scode').val();
		var sidcard = $('#sidcard').val();
		var sname = $('#sname').val();
		// var datastring = 'ref_join_id=1'+'&bu='+getBU+'&document_status='+docStatus;
		var datastring = "status="+status+"&dateStart="+dateStart+"&dateEnd="+dateEnd+"&scode="+scode+"&sidcard="+sidcard+"&sname="+sname;


		window.open('<?php echo base_url(); ?>cmsadmin/export_excel/export_data?id='+id);
	}

</script>


