<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php echo TITLE; ?></title>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta http-equiv="cache-control" content="max-age=0" /> <!-- 31536000 -->
		<meta http-equiv="cache-control" content="no-cache" />
		<meta http-equiv="expires" content="0" />
		<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
		<meta http-equiv="pragma" content="no-cache" />
		
		<meta NAME="Keywords" CONTENT="<?php echo META_KEYWORDS; ?>">
		<meta NAME="Description" CONTENT="<?php echo META_DESC; ?>">
		<link rel="shortcut icon" href="<?php echo URLFRONT; ?>assets/images/favicon.ico" />
			
		<link rel="stylesheet" href="<?php echo URLFRONT; ?>assets/css/bootstrap.min.css?v=<?php echo date('mis'); ?>" />
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/screen.css?v=<?php echo date('mis'); ?>" />
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/style.css?v=<?php echo date('mis'); ?>" />
		
		<script type="text/javascript" src="<?php echo URLFRONT; ?>assets/js/jquery-3.3.1.min.js?v=<?php echo date('mis'); ?>"></script>
		<script type="text/javascript" src="<?php echo URLFRONT; ?>assets/js/bootstrap.min.js?v=<?php echo date('mis'); ?>"></script>
		
	</head>
	<body>
		<div class="container" style="padding-top: 180px;">
			<div class="row" >				
				<form id="from1" name="from1" method="post" action="">
					<div class="col-md-6 col-md-offset-3" style="background-color: #333333">
						<div class="panel panel-default" style="margin-top:20px; background-color:#F5F5F5;">
							<div class="panel-body" >
								<span class="alignCenter"><h4 style="font-size:22px">Content Management System (CMS)</h4></span>
								<br />
								
								<table width="450" align="center" id="acc-details" >
									<tr>
										<td width="180" height="130" rowspan="3" align="left" style="padding: 10px 30px 0 0;" valign="top"><span><img src="<?php echo URLFRONT; ?>assets/images/logo_chanel.png" class="img-responsive" /></span></td>
										<td align="left">
											<input name="user" id="user" type="text" class="usernamebox" size="25" value="Username" maxlength="10" onkeyup="text(this.value);" onkeypress="CheckTXT();" onkeydown="javascript:if(event.keyCode==13)GoLog();" onclick="username_clear();" onblur="text_notclear();" onfocus="username_clear();" autocomplete="off"  />
										</td>
										<td rowspan="2" align="left"><img src="<?php echo $uri; ?>assets/images/login/button_login.png" width="67" height="72" align="left" style="margin-left:5px;cursor:pointer" onclick="GoLog();" onkeypress="keypressed();" />
										<input name="act" type="hidden" id="act" value="login" /><input type="hidden" id="param" name="param" value="th"/></td>
									</tr>
									<tr>
										<td align="left">
											<input name="pass" id="pass" type="password" class="passwordbox" size="25" value="" maxlength="10" height="40" onclick="password_clear();" onblur="text_notclear();" onkeypress="CheckPASS();" autocomplete="off" onfocus="password_clear();" onkeydown="javascript:if(event.keyCode==13)GoLog();"/>
										</td>
									</tr>
									<tr>
										<td width="180" >&nbsp;</td>
										<td></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		
		<script type="text/javascript">
			function keypressed(){
				if(event.keyCode=='13'){ GoLog(); }
			}
			
			function username_clear(){
				if(document.from1.user.value =='Username'){
					document.from1.user.value = "";
				}
			}
			
			function password_clear(){
				if(document.from1.pass.value ==""){
					document.from1.pass.value = "";
				}
			}
			
			function text_notclear(){
				if(document.from1.user.value == ""){
					document.from1.user.value ="Username";					
				}
			}
			
			function text(){
				var s = document.from1.user.value;
				 
				var re = /[\!$%^&*(){}<>:;'\"]/; 
				var re1 = /[\!$%^&*(){}<>:;'\"]/; 
				var result = s.match(re);    				
				
				if(result!=null){							
				    document.from1.user.value="";
					document.from1.pass.value="";
					return false ;
				}
			}
			
			function CheckTXT(){  
				if ((event.keyCode == 32)||(event.keyCode >= 48 && event.keyCode <= 57)||(event.keyCode >= 65 && event.keyCode <= 90)||(event.keyCode >= 97 && event.keyCode <= 122)){event.returnValue = true; }
				else{event.returnValue = false;  }
			}
			
			function CheckPASS(){  
				if ((event.keyCode == 32)||(event.keyCode == 46)||(event.keyCode >= 48 && event.keyCode <= 57)||(event.keyCode == 64)||(event.keyCode >= 65 && event.keyCode <= 90)||(event.keyCode >= 97 && event.keyCode <= 122)){event.returnValue = true; }
				else{event.returnValue = false;  }
			}
			
			function GoLog() { 
				var user = document.getElementById('user').value;
				var pass = document.getElementById('pass').value;	
				if (user == '' || user == 'Username'){
					alert("Please fill Username.");
					document.getElementById('user').focus();  return false;
				}else if (pass == ''){
					alert("Please fill in Password.");
					document.getElementById('pass').focus(); return false;	
				}else{		
					var datastring='username='+user+'&password='+pass;

					$.ajax({
						type:'POST',
						url:"<?php echo base_url();?>cmsadmin/login/check_login/",
						data:datastring,
						success:function(data){ 							
							if(data == 'ok'){ // is login complete									
								window.location.href = "<?php echo site_url('cmsadmin/campaign/camp_list'); ?>";							
							}else if(data == 'fail'){ // is login false
								alert("Please Check username or password!");
							}else if(data == 'expire'){
								alert("Username expire  Please contact admin.");
							}
						}
					});					
				}
			}
			
		</script>
	</body>
</html>