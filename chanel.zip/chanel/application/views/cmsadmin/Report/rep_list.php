<div class="page-header breadcamp"><?php echo anchor('cmsadmin/report/camp_list','Campaign')." > ".$camp_name." > Report"?></div>		
<div style="padding:7px 7px 7px 0;">
	<a href="<?php echo base_url()?>cmsadmin/report/camp_list"><button class="btn btn-secondary btn-sm" type="button" ><span data-feather="arrow-left-circle"></span> กลับ</button></a>		
</div>

<div class="row">
    <div class="col-lg-12">
		<?php if(isset($_GET['alert'])){
		echo "<div class=\"alert alert-success alert-dismissible fade show\" role=\"alert\">
		<strong>Import Success
		<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
		  <span aria-hidden=\"true\">&times;</span>
		</button>
	  </div>";
		}?>          
    </div>
	
</div>


<div class ="row">
	<div class = "col-md-8">
		
	</div>
	
	<div class = "col-md-2" style="padding-right: 0;">
	<button type="button" class="btn btn-secondary btn-sm" onclick="Btn_refresh();" style="float: right;" ><i class="fa fa-repeat"></i>&nbsp; Refresh</button>
	</div>
	<div class = "col-md-2">
		<button class= "btn btn-info btn-sm" style="float: right;margin-left: 15px;" onclick="exportDocument(<?php echo $camp_id?>);">Export Excel</button>
	</div>
</div>
<br>

			<form name="form_search" name="form_search" method="post" action="<?php echo base_url()."cmsadmin/report/rep_list/".$camp_id?>">
				<div class="form-group row">
					<div class="col-md-2">
						<input type="hidden" name="idcampign" id="idcampign" class="form-control form-control-sm" value="<?php echo $camp_id ?>" />	
						<input type="text" name="tel" id="tel" class="form-control form-control-sm" value="<?php echo $tel_no ?>" maxlength="10" onkeyup="this.value = this.value.toUpperCase();"  placeholder="ค้นหาเบอร์โทรศัพท์ :" onfocus="clearField(this);"/>	
					</div>
					<div class="col-md-2">
						<input type="text" name="dateStart" id="dateStart" class="form-control form-control-sm" value="<?php echo $url_start ?>"  placeholder="ค้นหาวันที่ :" onfocus="clearField(this);" readonly="true"/>	
					</div>
					<div class="col-md-2">
						<input type="text" name="dateEnd" id="dateEnd" class="form-control form-control-sm" value="<?php echo $url_end ?>" placeholder="ถึงวันที่:" onfocus="clearField(this);"  readonly="true"/>
					</div> 
					<div class="col-md-2">
						<input type="text" name="url" id="url" class="form-control form-control-sm" value="<?php echo $url ?>" maxlength="50"  placeholder="ค้นหา URL :" onfocus="clearField(this);"/>	
					</div>
					<div class="col-md-2">
						<input type="text" name="scode" id="scode" class="form-control form-control-sm" value="<?php echo $store_code ?>" maxlength="3" placeholder="ค้นหารหัสสาขา :" onfocus="clearField(this);"/>	
					</div>
					<div class="col-md-2">
						<input type="text" name="sname" id="sname" class="form-control form-control-sm" value="<?php echo $store_name ?>" maxlength="20" placeholder="ค้นหาชื่อสาขา :" onfocus="clearField(this);"/>	
					</div>
				 
				</div>
				<div class="col-md-12" style="padding-right:0;">
					<input type="submit" name="search" id="search" value="Search" class="btn btn-info " style="float: right;"/>
					<br/><br/>
				</div>
			</form>

<div class="table-responsive"> <br>
	<table class="table table-striped table-sm" id="myTable">
		<thead>
			<tr>
				<th width="5%" style="text-align:center;" >ลำดับ</th>
				<th width="10%" style="text-align:center">ชื่อกิจกรรม</th>
				<th width="10%" style="text-align:center">เบอร์โทรศัพท์</th>
				<th width="15%" style="text-align:center;">วันที่คลิก URL</th>
				<th width="15%" style="text-align:center;">วันที่กดใช้สิทธิ์</th>
				<th width="25%" style="text-align:center;">URL</th>
				<th width="10%" style="text-align:center;">รหัสสาขา</th>
				<th width="15%" style="text-align:center;">ชื่อสาขา</th>
			</tr>
		</thead>
		<tbody id="tbody">
			<?php echo $data_list; ?>
		</tbody>
	</table>
</div>

<link rel="stylesheet" href="<?php echo $this->Main_function->html_chars(base_url()); ?>assets/css/jquery.ui.css?v=021419" />
<style>.ui-datepicker {width: 200px;font-size: 14px;}</style>
<script type="text/javascript" src="<?php echo $this->Main_function->html_chars(base_url()); ?>assets/js/jquery-ui.min.js?v=021419"></script>

<link rel="stylesheet" media="all" type="text/css" href="<?php echo base_url()?>assets/js/jquerydatepicker/jquery-ui.css?v=<?php echo date("YmdHis")?>" />
<link rel="stylesheet" media="all" type="text/css" href="<?php echo base_url()?>assets/js/jquerydatepicker/jquery-ui-timepicker-addon.css?v=<?php echo date("YmdHis")?>" />

<script type="text/javascript" src="<?php echo $uri; ?>assets/js/jquerydatepicker/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo $uri; ?>assets/js/jquerydatepicker/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="<?php echo $uri; ?>assets/js/jquerydatepicker/jquery-ui-sliderAccess.js"></script>
<script>
	$('document').ready(function(){

		$('#myTable').DataTable({ 
					// "bLengthChange": false,
				"bInfo": false,
				// "pagingType": "full_numbers",
				"searching": false,
				// "pageLength": 15,

				"dom": '<"top"fl>rt<"bottom"p><"clear">',
				"language": {
				"lengthMenu": "Display _MENU_ Records per page",
				"zeroRecords": "No record found",
				"info": "Display _START_ to _END_ of _TOTAL_ Records",
				"infoEmpty": "No records available",
				"infoFiltered": "(filtered from _MAX_ total records)"
			},
			"lengthMenu": [[25, 50, 100, 500], [25, 50, 100, 500]],
		});
       
		i = "";
		c = "";

		$( function() {
			var availableTags = [
				"PHP"
				];
			$( "#tel" ).autocomplete({
				source: availableTags
			});
			$( "#dateStart" ).autocomplete({
				source: availableTags
			});
			$( "#dateEnd" ).autocomplete({
				source: availableTags
			});
			$( "#url" ).autocomplete({
				source: availableTags
			});
			$( "#scode" ).autocomplete({
				source: availableTags
			});
			$( "#sname" ).autocomplete({
				source: availableTags
			});

			$("#tel").keyup(function(event){
				if(isNaN(event.key)){
					//ถ้าไม่ใช่ number isNaN == ture
					if(event.keyCode == 8){
						// กรณีเป็น backspace
						let j = i.length - 1;
						console.log("j => ",j);
						i = i.substring(0, j);
					}else{
						$("#tel").val("");
						$("#tel").val(i);
					}
				}
				else{
					//อันนี้ถ้าเป็น number isNaN = false
					i += event.key;
				}
				console.log(i);
			
			});

			$("#scode").keyup(function(event){
				if(isNaN(event.key)){
					//ถ้าไม่ใช่ number isNaN == ture
					if(event.keyCode == 8){
						// กรณีเป็น backspace
						let j = c.length - 1;
						console.log("j => ",j);
						c = c.substring(0, j);
					}else{
						$("#scode").val("");
						$("#scode").val(c);
					}
				}
				else{
					//อันนี้ถ้าเป็น number isNaN = false
					c += event.key;
				}
				console.log(c);
				
			});

		} );
	
	});

	function clearField(input) {
		input.value = null;
	};

	$(function(){
		var startDateTextBox = $('#dateStart');
		var endDateTextBox = $('#dateEnd'); 
		
		startDateTextBox.datepicker({ 
			dateFormat: 'dd M yy',
			onClose: function(dateText, inst) {
				if (endDateTextBox.val() != '') {
					var testStartDate = startDateTextBox.datetimepicker('getDate');
					var testEndDate = endDateTextBox.datetimepicker('getDate');
					if (testStartDate > testEndDate)
						endDateTextBox.datetimepicker('setDate', testStartDate);
				}
				else {
					endDateTextBox.val(dateText);
				}
			},
			onSelect: function (selectedDateTime){
				endDateTextBox.datetimepicker('option', 'minDate', startDateTextBox.datetimepicker('getDate') );
			}
		});

		endDateTextBox.datepicker({ 
			dateFormat: 'dd M yy',
			onClose: function(dateText, inst) {
				if (startDateTextBox.val() != '') {
					var testStartDate = startDateTextBox.datetimepicker('getDate');
					var testEndDate = endDateTextBox.datetimepicker('getDate');
					if (testStartDate > testEndDate)
						startDateTextBox.datetimepicker('setDate', testEndDate);
				}
				else {
					// startDateTextBox.val(dateText);
				}
			},
			onSelect: function (selectedDateTime){
				startDateTextBox.datetimepicker('option', 'maxDate', endDateTextBox.datetimepicker('getDate') );
			}
		});

	});

	function Btn_refresh(){
		var camp_id = $("#idcampign").val()
		document.getElementById('tel').value = '';
		document.getElementById('scode').value = '';
		document.getElementById('sname').value = '';
		document.getElementById('url').value = '';
		document.getElementById('dateStart').value = '';
		document.getElementById('dateEnd').value = '';
		window.location.href='<?php echo base_url();?>cmsadmin/report/rep_list/'+camp_id;;
	}

	function exportDocument(camp_id){
		// console.log(camp_id); return false;
		
		var tel  = $('#tel').val();
		var dateStart = $('#dateStart').val();
		var dateEnd = $('#dateEnd').val();
		var scode = $('#scode').val();
		var sname = $('#sname').val();
		var url = $('#url').val();
		var camp_id = $('#idcampign').val();
		var datastring = "camp_id="+camp_id+"&tel="+tel+"&dateStart="+dateStart+"&dateEnd="+dateEnd+"&scode="+scode+"&sname="+sname+"&url="+url;


		window.open('<?php echo base_url(); ?>cmsadmin/export_excel/export_report?'+datastring);
	}

</script>


