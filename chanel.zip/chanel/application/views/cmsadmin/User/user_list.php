<script src="<?php echo $uri; ?>assets/js/jquery.bootgrid.js?v=<?php echo date('mis'); ?>"></script>
<script src="<?php echo $uri; ?>assets/js/jquery.bootgrid.fa.js?v=<?php echo date('mis'); ?>"></script>
<link href="<?php echo $uri; ?>assets/css/jquery.bootgrid.css?v=<?php echo date('mis'); ?>" rel="stylesheet" />

<table width="100%">
	<tr>
		<td width="50%"><div class="page-header breadcamp">User Management</div></td>
	</tr>
</table>
<div>
	<?php if($this->session->userdata('uicnauthorize') == "Admin"){ ?>
		<a class="btn btn-info btn-sm" href="<?php echo $uri;?>cmsadmin/user/user_manage" role="button">+ เพิ่ม User</a>
	<?php } ?>
</div>
<p>
	<!-- data-selection="true" data-multi-select="true" data-row-select="true" data-keep-selection="true" -->
	<table id="grid" class="table table-condensed table-hover table-striped" id="myTable" >
		<thead>
			<tr>
				<!-- <th data-column-id="id" data-type="hidden" data-visible="true">Hidden</th> -->
				<th data-column-id="no" data-identifier="true" data-order="asc" data-type="numeric" data-align="center" data-header-align="center" data-width="100px">ลำดับ</th>
				<th data-column-id="name" data-align="left" data-header-align="left" data-width="50%">Username</th>
				<th data-column-id="type" data-align="left" data-header-align="left" data-width="100px">Roles</th>
				<th data-column-id="status" data-align="left" data-header-align="left" data-width="100px">สถานะ</th>
				<th data-column-id="update" data-type="date" data-width="180px">แก้ไขล่าสุด</th>
				<th data-column-id="commands" data-formatter="commands" data-sortable="false" data-width="100px">Actions</th>				
			</tr>
		</thead>
		<tbody>
			<?php echo $tablelist;?>
		</tbody>
	</table>
</p>	

<script>
	$('document').ready(function(){
		$('#myTable').DataTable({
			"bLengthChange": false,
			"bInfo": false
		});
    }); 
	
	function deleteForm(id, name)
	{
		var conf = confirm("Do you want to delete this form?");
		if(conf == true)
		{
			location.href='<?php echo base_url()?>cmsadmin/user/user_status/'+id+'/D/'+name;
		}else
		{
			return false;
		}
	}
	
	function DelAction(id){		
		if (confirm("Are you sure you want to delete?")) {
			$.ajax({
				data: "user_id=" + id,
				method: "post",
				url: "<?php echo base_url('cmsadmin/user/user_delete') ?>"
			}).done(function(e) {
				if(e == 'pass'){
					alert('Delete data already.'); location.href='<?php echo base_url('cmsadmin/user/user_list') ?>';
				}
			})
		}
	}
</script>     
