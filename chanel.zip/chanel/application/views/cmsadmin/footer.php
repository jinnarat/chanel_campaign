				</main>
			</div>
		</div>
		
		<?php $uri = $this->Main_function->html_chars(base_url()); ?>
		<script type="text/javascript" src="<?php echo $uri; ?>assets/js/feather-icons.min.js?v=<?php echo date('mis'); ?>"></script>
		<script>
			feather.replace();
		</script>
	</body>
</html>