<?php $uri = $this->Main_function->html_chars(base_url()); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php echo TITLE; ?></title>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta http-equiv="cache-control" content="max-age=0" /> <!-- 31536000 -->
		<meta http-equiv="cache-control" content="no-cache" />
		<meta http-equiv="expires" content="0" />
		<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
		<meta http-equiv="pragma" content="no-cache" />
		
		<meta NAME="Keywords" CONTENT="<?php echo META_KEYWORDS; ?>">
		<meta NAME="Description" CONTENT="<?php echo META_DESC; ?>">
		<link rel="shortcut icon" href="<?php echo URLFRONT; ?>assets/images/favicon.ico" />
			
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/bootstrap-4.0.css?v=<?php echo date('mis'); ?>" />
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/dashboard.css?v=<?php echo date('mis'); ?>" />
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/summernote-bs4.css?v=<?php echo date('mis'); ?>" />
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/datatable.css?v=<?php echo date('mis'); ?>" />
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/dataTables.bootstrap.min.css?v=<?php echo date('mis'); ?>" />
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/style.css?v=<?php echo date('mis'); ?>" />
		
		<script type="text/javascript" src="<?php echo URLFRONT; ?>assets/js/jquery-3.3.1.min.js?v=<?php echo date('mis'); ?>"></script>
		<script type="text/javascript" src="<?php echo URLFRONT; ?>assets/js/popper.js?v=<?php echo date('mis'); ?>"></script>
		<script type="text/javascript" src="<?php echo $uri; ?>assets/js/bootstrap-4.0.js?v=<?php echo date('mis'); ?>"></script>
		<script type="text/javascript" src="<?php echo $uri; ?>assets/js/summernote-bs4.js?v=<?php echo date('mis'); ?>"></script>
		<script type="text/javascript" src="<?php echo $uri; ?>assets/js/datatable.js?v=<?php echo date('mis'); ?>"></script>
		<script type="text/javascript" src="<?php echo $uri; ?>assets/js/dataTables.bootstrap.min.js?v=<?php echo date('mis'); ?>"></script>
		
		<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/font-awesome.min.css" />
		<script>
        $('document').ready(function() {
            $("<?php echo (isset($menu) ? "#m_" . $menu : "") ?>").addClass("active");
			if($("<?php echo (isset($menu) ? "#m_" . $menu : "") ?>").hasClass("active")){
				$(this).removeClass("collapsed");
				$("<?php echo (isset($menu) ? "#" . $menu : "") ?>").removeClass("collapse");
				$("<?php echo (isset($menu_sub) ? "#m_" . $menu_sub : "") ?>").addClass("active");
			}
			
        }); 
		</script>
		
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		 
	</head>
	<body>
		<nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
			<div class="navbar-brand col-sm-3 col-md-2 mr-0" href="#" style="padding: unset;background-color: black;">
				<img src="<?php echo URLFRONT; ?>assets/images/Logo-Chanal.jpg" width="100%" height="auto" style="margin: 12px 0;">
			</div>
			<ul class="navbar-nav px-3">
				<li><span style='color: white;padding-right:7px;' class="fontMenu">Welcome <?php echo $this->session->userdata('uicnname');?></span></li>
				<li>
					<a href="<?php echo URLFRONT?>" target="_blank" class="fontMenu" style="color:gray">Go to Website</a>&nbsp;&nbsp;
					<a href="<?php echo $uri; ?>login/logout" class="fontMenu"> <span data-feather="log-out"></span> Logout</a>
				</li>
			</ul>
		</nav>
		<div class="container-fluid">
			<div class="row none_margin">
				<!-- Start Menu -->
				<nav class="col-md-2 d-none d-md-block bg-light sidebar" style="top:70px;">
					<div class="sidebar-sticky bar-size">
                    <ul class="nav flex-column">
						<?php echo $this->Main_function->getsMenuHeader($uri); ?>
					</ul>
				</nav>
				<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">