<div class="mainpage">
	<?php echo $data_content; ?>
</div>