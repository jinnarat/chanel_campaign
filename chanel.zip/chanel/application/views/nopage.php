

<div class="text-center">
	<img src="<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>" class="img-size" />
</div>