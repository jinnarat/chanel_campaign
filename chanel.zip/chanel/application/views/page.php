
<div class="text-center">
	<img src="<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>" class="img-size" />
</div>

<?php if($imgbut != ''){ ?>
	<div class="btn-click" align="center">
		<a href="<?php echo $link_page; ?>">
			<img src="<?php echo base_url().'uploads/f_content/'.$imgbut.'?v='.date('his'); ?>" class="img-fluid pos-btnimg" />
		</a>
	</div>
<?php } ?>