<div class="warp-content">
	<div class="container">
		<div class="row">
			<div class="bg-page">
				<div class="text-center">
					<img src="<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>" class="img-size" />
				</div>
			</div>
		</div>
	</div>
</div>