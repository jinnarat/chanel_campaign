
<link rel="stylesheet" href="<?php echo $uri; ?>assets/owl/owl.carousel.css?v=<?php echo date('mis'); ?>" />
<link rel="stylesheet" href="<?php echo $uri; ?>assets/owl/owl.carousel.min.css?v=<?php echo date('mis'); ?>" />
	
<script type="text/javascript" src="<?php echo $uri; ?>assets/owl/owl.carousel.min.js?v=<?php echo date("YmdHis")?>"></script>
<script type="text/javascript" src="<?php echo $uri; ?>assets/owl/owl.carousel.js?v=<?php echo date("YmdHis")?>"></script>


<?php if($type_style == 'N' || $type_style == ''){ ?>
	<div class="text-center">
		<img src="<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>" class="img-size" />
	</div>
	<div class="btn-click" align="center">
		<a href="<?php echo $link_page; ?>">
			<img src="<?php echo base_url().'uploads/f_content/'.$imgbut.'?v='.date('his'); ?>" class="img-fluid pos-btnimg" />
		</a>
	</div>
<?php }else{?>
	<div class="text-center">
		<img src="<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>" class="img-size" />
	</div>

	<?php if($page == '1'){ ?>
		<div class="main-content">
			<div class="nav-position">
				<div class="owl-carousel owl-theme">
							<?php
								if(count($img_slider) > 0){
									$dataList = $img_slider;
									for($i = 0; $i < count($img_slider);$i++) {
										echo $dataList[$i];
									}
								}
							?>
				</div>
				
				<div class="owl-theme">
					<div class="owl-controls">
						<div class="custom-nav owl-nav"></div>
					</div>
				</div>
			</div>
		</div>


	<?php }else{ 
		if($imgbut != ''){?>
		<div class="btn-click" align="center">
			<a href="<?php echo $link_page; ?>">
				<img src="<?php echo base_url().'uploads/f_content/'.$imgbut.'?v='.date('his'); ?>" class="img-fluid pos-btnimg" />
			</a>
		</div>
	<?php }} ?>

<?php } ?>


<script>
  $('.main-content .owl-carousel').owlCarousel({
  center: true,
  loop: true,
  margin: 2,
//   nav:true,
    navContainer: '.main-content .custom-nav',
    responsive:{
        0:{
            items:3,
			
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})
</script>
<style>

.nav-position{
	position: relative;
	width: calc(100% - 85px);
	margin: 0 auto;
}
.owl-item.cloned{
	width:100px;
}

.slider-btnimg{
	width: 70px !important;
	margin-left: auto;
	margin-right: auto;
}
.custom-nav {
	position: absolute;
	display: inline;
	right: 0;
	left: -50px;
    top: 20px;
    width: calc(100% + 95px);
}	

.owl-prev, .owl-next {
	position: absolute;
	height: 100px;
	color: inherit;
	background: none;
	border: none;
	z-index: 100;
	font-size: 47px;
}

.owl-prev {
	left: 5px;
}

.owl-next {
	right: -2px;
} 

.owl-item.active > div:after {
  /* width:100px !important; */
}
.owl-item.center > div:after {
  
}
.owl-item.active.center > div:after {
  
}
.owl-item > div:after {
  font-family: sans-serif;
  font-size: 24px;
  font-weight: bold;
}

.active.center {
  /* transform: scale(1);
  -webkit-filter: grayscale(0); 
    filter: grayscale(0); */
	margin-bottom: 40px;
}
.active.center .btn-picture{
    display: block;
	padding: 10px 0;
	/* margin-bottom: 40px; */
}
.active .btn-picture{
    display: none;
}
.active {
  /* transform: scale(.8);
  transition: .6s ease;
  -webkit-filter: grayscale(100%); 
    filter: grayscale(100%); */
	/* width: 120px !important; */
}
</style>
