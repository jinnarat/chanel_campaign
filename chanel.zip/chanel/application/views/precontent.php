<?php
// error_reporting(0);
class Precontent extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Content_model', 'contentdb');
        $this->load->helper('url');
    }
    public function index($cname=null, $gencode=null){
		if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
		$data['url_g']= "";
		$uri = $this->Main_function->html_chars(base_url());
		$url_gen = $this->contentdb->select_gencode("url_encode","sms_no",$gencode)->result_array();
		foreach($url_gen as $e){
               $data['url_g'] = htmlspecialchars_decode(trim($e['url_encode']));
            }
		if(count($url_gen) > 0 ){
				$urli = str_replace("cnB","==",$data['url_g']);
				$urlnumber = base64_decode($urli);
				$tel_no = substr($urlnumber,0,-1);
				$campid = substr($urlnumber,10,15);
				$time = date("Y-m-d H:i:s");
				$_SESSION['tel'] = $tel_no;
				$_SESSION['campid'] = $campid;
				$this->contentdb->updatedatetostart("sms_no",$tel_no,$campid,$time,'');
				$this->getdatahome();
		}else {
			http_response_code(404);
			include('my_404.php');
			die();
		}
		
	}
    
 
    public function getdatahome(){

        $uri = $this->Main_function->html_chars(base_url());

        $this->load->helper('date');
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $time = date("Y-m-d H:i:s");
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];

        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
            $rs = $this->contentdb->select_data("*", "content", $campid, "1")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                    $this->load->view('template/header');
		            $this->load->view('home',$data);
		            $this->load->view('template/footer');
                }
            else {
                $this->redemption($campid);
            }
    }
    public function datapage1($pageno, $campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage2/3/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                    $this->load->view('template/header');
		            $this->load->view('page1',$data);
		            $this->load->view('template/footer');
                }
            else{
                $this->redemption($campid);
            }
	
    }
    function datapage2($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage3/4/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
					$this->load->view('template/header');
					$this->load->view('page1',$data);
					$this->load->view('template/footer');
				}
            }
            else{
                $this->redemption($campid);
            }
    }
    function datapage3($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage4/5/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
                    $this->load->view('template/header');
		            $this->load->view('page1',$data);
		            $this->load->view('template/footer');
            }
        }
            else{
                $this->redemption($campid);
            }
    }
    function datapage4($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage5/6/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            
            if(count($rs) > 0){
                $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
					$this->load->view('template/header');
		            $this->load->view('page1',$data);
		            $this->load->view('template/footer');
                }
            }
            else{
                $this->redemption($campid);
            }

    }
    function datapage5($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage6/7/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
					$this->load->view('template/header');
		            $this->load->view('page1',$data);
		            $this->load->view('template/footer');
				}
            }
            else{
                $this->redemption($campid);
            }
    }
    function datapage6($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
		$data['title']= "";
        $data['detail']= "";
        $data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['img_alt']= "";
        $data['create_date']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage7/8/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
				
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
                    $this->load->view('template/header');
                    $this->load->view('page1',$data);
                    $this->load->view('template/footer');
                }
            }
            else{
                $this->redemption($campid);
            }
    }
    function datapage7($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
        $data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['img_alt']= "";
        $data['create_date']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage8/9/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
                    $this->load->view('template/header');
                    $this->load->view('page1',$data);
                    $this->load->view('template/footer');
                }
            }
            else{
                $this->redemption($campid);
            }
    }
    function datapage8($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
        $data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['img_alt']= "";
        $data['create_date']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage9/10/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
                    $this->load->view('template/header');
		            $this->load->view('page1',$data);
		            $this->load->view('template/footer');
            }
        }
            else{
                $this->redemption($campid);
            }
    }
    function datapage9($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
        $data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['img_alt']= "";
        $data['create_date']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
        $data['link_page']= $uri.'content/datapage10/11/'.$campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
                    $this->load->view('template/header');
		            $this->load->view('page1',$data);
		            $this->load->view('template/footer');
            }
        }
            else{
                $this->redemption($campid);
            }
    }
    function datapage10($pageno,$campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data['id']= "";
        $data['title']= "";
        $data['detail']= "";
        $data['img']= "";
        $data['img_alt']= "";
        $data['create_date']= "";
        $data['page_no']= "";
        $data['imgbut']="";
        $data['campid']= $campid;
            $rs = $this->contentdb->select_data("*", "content",$campid,$pageno)->result_array();
            $rs1 = $this->contentdb->select_data("*", "content", $campid, "16")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
					$data['title'] = htmlspecialchars_decode(trim($r['title']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['img_alt'] = htmlspecialchars_decode(trim($r['img_alt']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
                }
                if(count($rs1)>0){
                    foreach($rs1 as $e){
                        $data['imgbut'] = htmlspecialchars_decode(trim($e['img_name']));
                    }
                    $this->load->view('template/header');
		            $this->load->view('page1',$data);
		            $this->load->view('template/footer');
            }
        }
            else{
                $this->redemption($campid);
            }
        
    }
    function redemption($campid){
        $uri = $this->Main_function->html_chars(base_url());
        $data_header['TITLE'] = TITLE;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';
		$data_header['script_head'] = '';
		$data_header['script_body'] = '';
		$data_header['script_footer'] = '';
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';
		$data_content['head_title'] = '';
		$data_content['head_image'] = '';
        $data_content['head_detail'] = '';
        
        $data['img']= "";
        $data['campid']=$campid;
        $data['imgbut']="";
        $rs = $this->contentdb->select_data("*", "content",$campid,"11")->result_array();
        $rs1 = $this->contentdb->select_data("*", "content", $campid, "17")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
					$data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
            }
        $this->load->view('template/header', $data_header);
		$this->load->view('bapage',$data);
		$this->load->view('template/footer');
    } 
    function pagecheck(){
        $this->load->view('template/header');
		$this->load->view('ba_check');
		$this->load->view('template/footer');
    }
    function checkcodeshop(){
        // $uri = $this->Main_function->html_chars(base_url());
		$code = $this->input->post('code');
        $this->load->helper('date');
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];
        $time = date("Y-m-d H:i:s");
        $data['status'] = "";
        $rsg = $this->contentdb->select_shopcode("shop_code","store",$code)->result_array();
        if(count($rsg)== "1"){
        $rs = $this->contentdb->select_codeshop("status","sms_no",$tel_no,$campid)->result_array();
        foreach($rs as $r){
        $data['status'] = htmlspecialchars_decode(trim($r['status']));
        }
        if($data['status'] == 'N'){
                $this->contentdb->updatetoshopcode("sms_no",$tel_no,$campid,'Y');
                $this->contentdb->updatetoshop_code("sms_no",$tel_no,$campid,$code);
                $this->contentdb->updatedatetoend("sms_no",$tel_no,$campid,$time);
                $this->pass();
            }
            else {
                $this->nopass(); 
            }
        }
        else {
			$this->nodata(); 
        }
          
    }

    function pass(){

        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']="";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $campid = $_SESSION['campid'];

        $rs = $this->contentdb->select_data("*", "content",$campid,"12")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
                }
            }
        }
        $this->load->view('template/header', $data_header);
		$this->load->view('passpage',$data);
		$this->load->view('template/footer');
    }
    
    function nopass(){
        $uri = $this->Main_function->html_chars(base_url());
        $data['img']= "";
		$data['detail']= "";
		$data['imgbut']= "";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $campid = $_SESSION['campid'];

        $rs = $this->contentdb->select_data("*", "content",$campid,"13")->result_array();{
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
					$data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
            }
			$this->load->view('template/header');
			$this->load->view('nopasspage',$data);
			$this->load->view('template/footer');
        }
    }
	
	function checkstorecode(){
		$code = $this->input->POST('code');
		echo $code;
	}
	
	function checkcode(){
		$result = array();
		$code = $this->input->post("code");
		
		if($code){
			$result = 'pass';
		}
		
		echo json_encode($result);
		exit;
	}
	
	function nodata(){
		$data['img']= "";
		$data['detail']= "";
		$data['imgbut']= "";
        if(!isset($_SESSION)) 
            { 
                session_start(); 
            } 
        $tel_no = $_SESSION['tel'];
        $campid = $_SESSION['campid'];
        $date = now();
        $time = date("Y-m-d H:i:s",$date);

        $this->contentdb->insertdatetolog("log_status",$tel_no,$campid,$time,'I');
            $this->contentdb->updatedatetostart("sms_no",$tel_no,$campid,$time);
            $rs = $this->contentdb->select_data("*", "content", $campid, "18")->result_array();
            if(count($rs) > 0){
                foreach($rs as $r){
                    $data['id'] = htmlspecialchars_decode(trim($r['id']));
                    $data['img'] = htmlspecialchars_decode(trim($r['img_name']));
                    $data['page_no'] = htmlspecialchars_decode(trim($r['page_no']));
					$data['detail'] = htmlspecialchars_decode(trim($r['detail']));
					$data['imgbut'] = htmlspecialchars_decode(trim($r['img_btn']));
                }
                    $this->load->view('template/header', $data_header);
		            $this->load->view('nopage',$data);
		            $this->load->view('template/footer');
                }
            
	}
}
