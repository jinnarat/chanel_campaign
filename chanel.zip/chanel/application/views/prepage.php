
<!-- <div class="warp-content">
	<div class="container">
		<div class="row">
			<div class="bg-page">
				<div class="image" style="background: url(<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>) top center no-repeat; background-size: 100%;"></div>
				<div class="detail" align="center">
					<h5 style="font-family: ABChanel;font-size: 34px;font-family: thaiChanel;font-size: 36px;margin-top:0"><?php echo $title; ?></h5>
					<?php echo $detail ?>
				</div>
				<div class="btn-click" align="center">
					<a <img src="<?php echo base_url().'uploads/f_content/'.$imgbut.'?v='.date('his'); ?>" class="img-fluid pos-btnimg" /></a>
				</div>
			</div>
		</div>
	</div>
</div> -->

<div class="text-center">
	<img src="<?php echo base_url().'uploads/f_content/'.$img.'?v='.date('his'); ?>" class="img-size" />
</div>
<div class="btn-click" align="center">
	<!-- <a href="<?php echo $link_page; ?>"> -->
	<a href="#">
		<img src="<?php echo base_url().'uploads/f_content/'.$imgbut.'?v='.date('his'); ?>" class="img-fluid pos-btnimg" />
	</a>
</div>