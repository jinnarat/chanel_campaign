<?php
    $uri = $this->Main_function->html_chars(base_url()); 
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <title><?php echo 'Chanel'?></title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1,  user-scalable=no">

      <!-- Bootstrap CSS -->
      <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->
    
    <link rel="stylesheet" href="<?php echo $uri; ?>assets/css/bootstrap-4.3.1.css?v=<?php echo date("YmdHis")?>" />
    <link rel="stylesheet" href="<?php echo $uri; ?>assets/css/main-style.css?v=<?php echo date("YmdHis")?>" />
    
    <script type="text/javascript" src="<?php echo $uri; ?>assets/js/jquery-3.3.1.min.js?v=<?php echo date("YmdHis")?>"></script>
    <script type="text/javascript" src="<?php echo $uri; ?>assets/js/popper.min.js?v=<?php echo date("YmdHis")?>"></script>
    <script type="text/javascript" src="<?php echo $uri; ?>assets/js/bootstrap4.3.1.min.js?v=<?php echo date("YmdHis")?>"></script>

    <style>
       @font-face {
        font-family: ABChanel;
        src: url("<?php echo base_url(); ?>assets/fonts/ABChanelCORPO/ABChanelCorpo-Regular.otf");
      }
      @font-face {
        font-family: thaiChanel;
        src: url("<?php echo base_url(); ?>assets/fonts/ABChanelCORPO/KIT65F_1.TTF");
      }
      
      
        body{
          <?php if($bg != ''){ ?>
            background-color: <?php echo $bg; ?>;
          <?php }else{ ?>
            background-color: #ffffff;
          <?php } ?>
        }
      

    </style>

  </head>
    <body>
