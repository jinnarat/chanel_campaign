function setSizeLeftMenu() {
	var e = $(window).height(),
		t = $("#menu-button").height(),
		s = e - t,
		a = $(".nav_menu").height();
	$("#menu-button").removeClass("menu-opened");
	$(".nav_menu").removeClass("open");
	$(".nav_menu").removeAttr("style");
	$(".navbar-header").removeClass("hidden");
	if ($("#cssmenu").hasClass("small-screen")) {
		$(".navbar-header").addClass("hidden");
		// $(".navbar-header").css("display", "none");
		$(".nav_menu").height(s);
		if (a > s) {
			$(".nav_menu").css("overflow-y", "scroll");
		} else {
			$(".nav_menu").css("overflow-y", "scroll");
		}
	}
}

function checkint(el) {
	var ex = /^[0-9]*$/;
	if (ex.test(el.value) == false) {
		el.value = el.value.substring(0, el.value.length - 1)
	}
}

function changeLang(lang, alias){
	// console.log(alias);
	$.ajax({
		url: BaseUrl + lang + "/language/" + alias,
		type: "GET",
		// dataType: "json",
		// data: { 'bid' : idx, 'orderby' : data },
		success: function( result ) {
			// console.log(result);
			if(result){
				location.href = BaseUrl + result + "/";
			}
		}
	});
}

$(document).ready(function(){
	var val_scroll = 0;
	var txtpholder = '';
	var txtpholder_letter = '';
	if(LANG == 'th'){
		txtpholder = 'ค้นหา'; 
		txtpholder_letter = 'กรอกอีเมลล์เพื่อรับข่าวสารจากเรา'; 
	}else{
		txtpholder = 'Search';
		txtpholder_letter = 'Subscribe to our newsletter';
	}
	if (media == 'desktop') {
		val_scroll = 50;
	}
	
	if ($(window).scrollTop() > 0) {
		$(".header").addClass("navbar-fixed-top");
		// $("body").css("padding-top", "70px");
	} else {
		$(".header").removeClass("navbar-fixed-top");
	}
		
	$("#cssmenu").menumaker({
		title: "<a href='"+BaseUrl+"' title='ITAP โปรแกรมสนับสนุนการพัฒนาเทคโนโลยีของอุตสาหกรรมไทย'><img src='"+BaseUrl+"assets/images/logo_iTAP.png' class='img-responsive' alt='ITAP โปรแกรมสนับสนุนการพัฒนาเทคโนโลยีของอุตสาหกรรมไทย' title='ITAP โปรแกรมสนับสนุนการพัฒนาเทคโนโลยีของอุตสาหกรรมไทย' /></a>",
		breakpoint: 1024,
		format: "multitoggle"
	});
	
	$("#cssmenu li a").mouseover(function() {
		var elements = $(this).attr("href");
		if(elements == "#"){
			$(this).removeAttr('href');
		}
	});
	
	if ($("#cssmenu").hasClass("small-screen")) {
		setSizeLeftMenu();		
	}
	
	$("a[data-target^='#']").on("click", function(event) {
		var around = $("#around-click").attr("data-around"); 
		var divElements = $($(this).data("target"));
		// var position = divElements.position(); // alert(position.top - 300);
		var position = $($(this).data("target")).offset().top;
		
		var scrollDiv = 120;
		if(media == 'tablet') {
			scrollDiv = 150;
		}
		if (media == 'desktop') {
			scrollDiv = 170;
		}
		
		if($(window).scrollTop() == 0) {
			scrollDiv = 260;
			if(media == 'tablet') {
				scrollDiv = 310;
			}
			if (media == 'desktop') {
				scrollDiv = 330;
			}
		}
		
		
		position = position - scrollDiv;
		// alert(position);
		$("body, html").animate({
			scrollTop: position
		}, 1000);
		
		$("#around-click").attr("data-around", 1);
	});


	$('#sscribe').click(function(){
		$(this).attr("placeholder", "");
    }).focusout(function(){
		// $('#myBtnNlt').trigger("click");
		var mailletter = $(this).val().trim();
		if(mailletter == ""){
			$(this).attr("placeholder", txtpholder_letter);
		}else{
			// $("#subscribe_form").submit();
			chkNewsletter(mailletter);
		}
	}).keydown(function(){
		var mailletter = $(this).val().trim();
		if(event.keyCode=='13'){
			chkNewsletter(mailletter);
			return false;
		}else{
			
		}
	});
	
	$("#myBtnLetter").click(function(){
		var letter = $("#sscribe").val().trim();
		// alert(letter);
		$("#modal-body").empty();
		$("h4.modal-title").empty();
		$("h4.modal-title").append("Subscribe to our newsletter :");
		$("#bg-lock__process, #box-lock__process").css("display", "block");
		
		if(!letter){
			$("#modal-body").append('<p>Please, type email.</p>');
			$("#myAlert").trigger("click");
			$("#bg-lock__process, #box-lock__process").css("display", "none");
			$("#sscribe").focus();
			return false;
		}
	});
	
	function chkNewsletter(email){
		var mailletter = "";
		var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		
		if(email){
			mailletter = email;
		}else{
			mailletter = $('#sscribe').val().trim();
		}
		
		$("#modal-body").empty();
		$("h4.modal-title").empty();
		$("h4.modal-title").append("Subscribe to our newsletter :");
		$("#bg-lock__process, #box-lock__process").css("display", "block");
		
		if(mailletter){
			if(!mailformat.test(mailletter)){
				$("#modal-body").append('<p>Please, check format email.</p>');
				$("#myAlert").trigger("click");
				$("#bg-lock__process, #box-lock__process").css("display", "none");
				
				$("#myModal").on("hidden.bs.modal", function () {
					$("#sscribe").val("");
					$("#sscribe").focus();
				});
				return false;
			}else{
				// data: $("#frmSS60").serialize(),
				$.ajax({
					url: BaseUrl + LANG + "/subscribe/",
					type: "GET",
					data: {'ssemail': mailletter},
					dataType: "json"
				}).done(function(e){
					var result = e.result;
					var msgAlert = e.msg;
					if(result == "pass"){
						
						$("#modal-body").append('<p>Thank you. we will contact you as soon as possible.</p>');
						$("#myAlert").trigger("click");
						$("#bg-lock__process, #box-lock__process").css("display", "none");
						
						$("#myModal").on("hidden.bs.modal", function () {
							location.reload();
						});
					}else{
						$("#modal-body").append('<p>' + msgAlert +'</p>');
						$("#myAlert").trigger("click");
						$("#bg-lock__process, #box-lock__process").css("display", "none");
						return false;
					}
				});
			}
		}else{
			$("#modal-body").append('<p>Please, type email.</p>');
			$("#myAlert").trigger("click");
			$("#bg-lock__process, #box-lock__process").css("display", "none");
			$("#sscribe").focus();
			return false;
		}
	}
	
	$("#hd_btn_search").click(function (){
		var element = $("#hsearch");
		if(element.hasClass("open")) {
			// alert(element.val().trim());
			if(element.val().trim() == ""){
				element.animate({
					width: "0"
				});
				$(this).removeClass("open");
				element.removeClass("open");
				element.attr("placeholder", txtpholder);
			}else{
				$("#hd_search_form").submit();
			}
		}else {
			// $(this).css("background-image", "url(\'" + BaseUrl + "assets/images/icons/icon_search_hover.png\'");
			$(this).addClass("open");
			element.addClass("open");
			element.animate({
				width: "200px"
			});
			// element.attr("placeholder", "");
			// element.focus();
		}
		return false;
	});
	
	$('#hsearch').click(function(){
		$(this).attr("placeholder", "");
    }).focusout(function(){
		var element = $(this);
		var textsearch = element.val().trim();

		if(element.hasClass("open")) {
			element.animate({
				width: "0"
			});
			$("#hd_btn_search").removeClass("open");
			element.removeClass("open");
			element.attr("placeholder", txtpholder);
			if(textsearch == ""){
				element.val("");
				element.attr("placeholder", txtpholder);
			}else{
				$("#hd_search_form").submit();
			}
		}
	}).keydown(function(){
		var element = $(this);
		var textsearch = element.val().trim();
		
		if(event.keyCode=='13'){
			if(textsearch == ""){
				$("#modal-body").empty();
				$("h4.modal-title").empty();
				$("h4.modal-title").append(txtpholder + " :");
				$("#modal-body").append('<p>Please, type search.</p>');
				$("#myAlert").trigger("click");
				return false;
			}else{
				$("#hd_search_form").submit();
			}
			// return false;
		}
	});
	
	
	/* $("#hsearch").click(function(){
		$(this).attr("placeholder", "");
	}).focusout(function(){
		var element = $(this);
		var textsearch = element.val().trim();
		
		if(element.hasClass("open")) {
			if(textsearch == ""){
				element.animate({
					width: "0"
				});
				$("#hd_btn_search").removeClass("open");
				element.removeClass("open");
				element.attr("placeholder", txtpholder);
			}else{
				alert("search header");
				$("#hd_search_form").submit();
			}
		}
	});
	
	$("#hd_search_form").submit(function () {
		var element = $("#hsearch");
		alert("search header submit : " + element.val().trim());
		
		$("#modal-body").empty();
		$("h4.modal-title").empty();
		$("h4.modal-title").append("Search :");
		
		if(element.val().trim() == ""){
			$("#modal-body").append('<p>Please, type search.</p>');
			$("#myAlert").trigger("click");
			// alert("Please, type search.");
			return false;
		}
		return true;
	}); */
	
	$(".warp-detail__data > .detail img").removeAttr("style");
	$(".warp-detail__data > .detail img").addClass("img-responsive");
	
	/* $(".detail").find("table").each(function (index, value) {
		// $(value).css('color', 'red');
		// console.log(index + "," + value);
		var data = $(".detail").html();
		$(value).removeAttr("style");
		$(value).addClass("table");
		//console.log(data);
	}); */
	
	$(window).on("scroll", function () {
		var val_scroll = 0;
		if (media == 'desktop') {
			val_scroll = 50;
		}
		if($(window).scrollTop() > 0) {
			$(".header").addClass("navbar-fixed-top");
			// $("body").css("padding-top", "170px");
		} else {
			$(".header").removeClass("navbar-fixed-top");
		}
	});
	
	$(window).resize(function () {
		setSizeLeftMenu();
	});
});