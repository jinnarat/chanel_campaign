$(document).ready(function () {
	$('.dropdown-el').click(function(e) {
		e.preventDefault();
		e.stopPropagation();
		$(this).toggleClass('expanded');
		// $('#'+$(e.target).attr('for')).prop('checked', true);
			
		if($('#'+$(e.target).attr('for')).is(':checked')){
			// console.log("click");
			// console.log('#'+$(e.target).attr('for'));
		}else{
			// console.log("change");
			$('#'+$(e.target).attr('for')).prop('checked', true);
			var sortby = $("input[name='sortType']:checked").val();
			if(sortby){
				search();
			}
		}
	});
	
	$(document).click(function() {
		$('.dropdown-el').removeClass('expanded');
	});
	
	$(".myBtnSearch").click(function() {
		search();
	});
	
	$("input[name='downsearch']").click(function() {
		$(this).attr("placeholder", "");
	}).focusout(function() {
		var value = $(this).val().trim();
		var inp_ph_down = 'Search';
		if(value == ""){
			if(LANG == "th"){ inp_ph_down = 'ค้นหา'; }
			$(this).attr("placeholder", inp_ph_down);
		}else{
			// alert('Search');
			search();
		}
	}).keydown(function() {
		if(event.keyCode=='13'){
			search();
			// alert('Search');
		}
	});
	
	$("#frmDsearch").submit(function () {
		// alert('frmSearch');
		var textsearch = $("#downsearch").val().trim();
		
		search();
		return false;
	});
	
	function search(){
		// console.log('search');
		// console.log('select : ' + $("input[name='sortType']:checked").val());
		// console.log('search : ' + $("input[name='downsearch']").val());
		
		var data_search = '';
		var sortby = $("input[name='sortType']:checked").val();
		var inp_search = $("input[name='downsearch']").val();
		
		if(sortby){
			data_search = sortby + "/";
		}
		if(inp_search){
			data_search += inp_search + "/";
		}

		if(sortby != "" || inp_search != ""){
			
			$.ajax({
				// data: 'id='+id+'&id_order='+order+'&order='+data,
				// data: {'id': id, 'id_order': order, 'order': data}
				// url: BaseUrl + LANG + "/download/search/" + data_search,
				url: BaseUrl + LANG + "/download/search/",
				type: "GET",
				data: {'sortby' : sortby, 'search' : inp_search},
				dataType: "json"
			}).done(function(data){
				var result = data.data_download;
				// console.log(data);
				// console.log('sortby : ' + data.sortby);
				// console.log('search : ' + data.search);
				$("#result").empty();
				
				if(result){
					$("#result").append(result);
				}
			});
		}
	}

});