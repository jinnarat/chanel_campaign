$(document).ready(function () {
	var banner_slider;
	
	if($(".banner-slider").children().length > 0){
		var banner_lenght = $(".banner-slider").children().length;
		banner_slider = $(".banner-slider").bxSlider({mode: "fade", auto: (banner_lenght < 2) ? false : true, pause: 4000, speed: 2000, controls: true, pager: (banner_lenght < 2) ? false : true, touchEnabled: false, adaptiveHeight: true, infiniteLoop: (banner_lenght <= 1) ? false : true, onSlideAfter: function() { pause: 4000 }});
		/* banner_slider = $(".banner-slider").bxSlider({ mode: "fade", auto: ($(".banner-slider").children().length < 2) ? false : true, pause: 10000, speed: 4000, controls: true, pager: ($(".banner-slider").children().length < 2) ? false : true, adaptiveHeight: true, infiniteLoop: ($(".banner-slider").children().length <= 1) ? false : true, onSlideAfter: function() { pause: 10000 } }); */
		
	}
	
	$(".box-content img").addClass("img-responsive");
	$(".box-content img").removeAttr("style");
	
	$(".box-content").find("table").each(function (index, value) {
		// $(value).css('color', 'red');
		// console.log(index + "," + value);
		var data = $(".box-content").html();
		
		// $(value).removeAttr("style");
		// $(value).addClass("table");
		// console.log(data);
		// console.log(index);
		// console.log(value);
		if(media != "desktop"){
			$(value).css("width", "100%");
		}
		
	});
	
	/* if($("#cssmenu li").hasClass("active")) {
		var nav_id = $("#cssmenu li").attr("id").replace('m-', '');
		var str = nav_id.replace('m-', '');
		$("#"+nav_id).addClass("active");
		
		if($(".header").hasClass("navbar-fixed-top")){
			if($("#"+nav_id).hasClass("active")){
				// $("#"+nav_id).css("margin-top", "170px");
			}
		}
	} */
	
	$("#cssmenu li").click(function () {
		var mid = $(this).attr("id");
		var re_mid = mid.replace('m-', '');
		$("#cssmenu li").removeClass("active");
		$("#"+mid).addClass("active");
		// $(".wrap-hl__content").css("padding-top","180px");
		$("#"+re_mid).addClass("active");
		// $("#"+re_mid).css("padding-top","320px");
		// console.log(mid);
	});
	
	if($("#m-what").hasClass("active")) {
		$(".box-content").removeAttr("style");
	}
	
	$(window).on("scroll", function () {
		// $("#what").css("margin-top", "350px");
		// $(".wrap-hl__content .wrap-content").removeAttr("style");
		
		if($("#what").hasClass("active")) {

		}
	});
	
	$(window).resize(function() {
		var windowsize = $(window).width();
		var documentwidth = $(document).width();
		var _SCREEN_ = (window.devicePixelRatio * screen.width) / window.devicePixelRatio;
		var S = window.innerWidth;
		var media = "desktop";
		if((_SCREEN_ <= 1280 && _SCREEN_ >= 768) || (S <= 1280 && S >= 768)){
			media = "tablet";
		}
		if(_SCREEN_ < 768 || S < 768){
			media = "mobile";
		}
		
		$(".box-content").find("table").each(function (index, value) {
			// $(value).css('color', 'red');
			// console.log(index + "," + value);
			var data = $(".box-content").html();
			
			// $(value).removeAttr("style");
			// $(value).addClass("table");
			// console.log(data);
			// console.log(index);
			if(media != "desktop"){
				$(value).css("width", "100%");
			}
			
		});
	});
});