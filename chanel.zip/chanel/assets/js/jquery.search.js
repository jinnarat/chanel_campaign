function chkSsearch(val){
	// alert('chkSsearch');
	$("#modal-body").empty();
	$("h4.modal-title").empty();
	$("h4.modal-title").append("Search :");
	
	if(val == ""){
		// $("#modal-body").append('<p>Please, type email.</p>');
		// $("#myAlert").trigger("click");
		return false;
	}
	return true;
}

$(document).ready(function(){
	var txtpholder = '';
	if(LANG == 'th'){ txtpholder = 'ค้นหา'; }else{ txtpholder = 'Search'; }
	
	$("#hssearch").click(function(){
		var element = $(this);
		var textsearch = element.val().trim();
		
		$(this).attr("placeholder", "");
		if(textsearch != ""){
			element.val("");
		}
		
	}).focusout(function(){
		var element = $(this);
		var textsearch = element.val().trim();
		
		if(textsearch == ""){
			element.attr("placeholder", txtpholder);
		}else{
			// alert('search');
			$("#frmSearch").submit();
			return false;
		}
	});
	
	$("#frmSearch").submit(function () {
		// alert('frmSearch');
		var textsearch = $("#hssearch").val().trim();
		
		chkSsearch(textsearch);
		return false;
	});
	
	
	/* $("#hssearch").click(function(){
		$(this).attr("placeholder", "");
	}).focusout(function(){
		var element = $(this);
		var textsearch = element.val().trim();
		
		if(textsearch == ""){
			element.attr("placeholder", txtpholder);
		}else{
			alert('frmSearch');
			chkSsearch();
			// $("#frmSearch").submit();
		}
	}).keydown(function(){

		if(event.keyCode=='13'){
			chkSsearch();
			return false;
		}else{
			
		}
	}); */
	
	/* $("#frmSearch").submit(function () {
		var element = $("#hssearch");
		
		$("#modal-body").empty();
		$("h4.modal-title").empty();
		$("h4.modal-title").append("Search :");
		
		if(element.val().trim() == ""){
			$("#modal-body").append('<p>Please, type search.</p>');
			$("#myAlert").trigger("click");
			// alert("Please, type search.");
			return false;
		}
		return true;
	}); */
	
	/* function chkSsearch(){
		alert('frmSearch : ');
		return false;
	} */
	
});