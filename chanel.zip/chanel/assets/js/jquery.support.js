$(document).ready(function () {
	var video_slider, video_slider_mobile, news_slider, news_slider_mobile;

	var video_lenght = $(".video-slider").children().length;
	var video_mobile_lenght = $(".video-slider-mobile").children().length;
	var news_lenght = $(".news-slider").children().length;
	var news_mobile_lenght = $(".news-slider-mobile").children().length;
	
	if(media != "mobile"){
		if($(".video-slider").children().length > 0){
			video_slider = $(".video-slider").bxSlider({ auto: false, speed: 1000, controls: true, pager: true, pagerCustom: "#bx-pager-vdo", nextSelector: '.video-next', nextText: '>>', infiniteLoop: false, adaptiveHeight: false, onSliderLoad: function(){ if(video_lenght < 2){ $("#bx-pager-vdo").css("display", "none"); } } });
		}
		if($(".news-slider").children().length > 0){
			news_slider = $(".news-slider").bxSlider({ auto: false, speed: 1000, controls: true, pager: true, pagerCustom: "#bx-pager-news", nextSelector: '.news-next', nextText: '>>', infiniteLoop: false, adaptiveHeight: true, onSliderLoad: function(){ if(news_lenght < 2){ $("#bx-pager-news").css("display", "none"); } } });
		}
	}
	if(media == "mobile"){
		if($(".video-slider-mobile").children().length > 0){
			video_slider_mobile = $(".video-slider-mobile").bxSlider({ auto: false, speed: 1000, minSlides: 2, maxSlides: 2, slideWidth: 400, slideMargin: 15, controls: true, pager: true, pagerCustom: "#vdo-pager-mobile", nextSelector: '.video-next', nextText: '>>', moveSlides: 1, infiniteLoop: (video_mobile_lenght < 3) ? false : true, onSliderLoad: function(){ if(video_mobile_lenght < 3){ $("#vdo-pager-mobile").css("display", "none"); } } });
		}
		if($(".news-slider-mobile").children().length > 0){
			video_slider_mobile = $(".news-slider-mobile").bxSlider({ auto: false, speed: 1000, controls: true, pager: true, pagerCustom: "#news-pager-mobile", nextSelector: '.news-next', nextText: '>>', moveSlides: 1, infiniteLoop: (news_mobile_lenght < 2) ? false : true, onSliderLoad: function(){ if(news_mobile_lenght < 2){ $("#news-pager-mobile").css("display", "none"); } } });
		}
	}
	
	/* $('.pager-next').click(function(){
		var current = video_slider.getCurrentSlide();
		video_slider.goToNextSlide(current) + 1;
	}); */
	
	$(".video-image").click(function(){
		var vdoid = $(this).find("img").data("id");
		if(vdoid){
			$.ajax({
				url: BaseUrl + LANG + "/news/change_video/",
				type: "GET",
				data: {'vdoid' : vdoid},
				dataType: "json"
			}).done(function(result){
				var video = result.video_link;
				// console.log(result);
				// console.log('vdo id : ' + result.video_id);
				// console.log('vdo data : ' + result.video_data);
				// console.log('vdo link : ' + result.video_link);
					
				if(video){
					// $("#hl-video").empty();
					// $("#hl-video").append(video);
					$("#hl-video iframe").attr("src", "https://youtube.com/embed/"+video+"?autoplay=1&controls=0&showinfo=0&autohide=1&rel=0");
					
					// https://youtube.com/embed/7bkHtMw620M?autoplay=0&controls=0&showinfo=0&autohide=1&rel=0
				}
			});
		}
	});
	
	$(window).on("scroll", function () {

	});
	
	$(window).resize(function() {
		var windowsize = $(window).width();
		var documentwidth = $(document).width();
		var _SCREEN_ = (window.devicePixelRatio * screen.width) / window.devicePixelRatio;
		var S = window.innerWidth;
		var media = "desktop";
		if((_SCREEN_ <= 1280 && _SCREEN_ >= 768) || (S <= 1280 && S >= 768)){
			media = "tablet";
		}
		if(_SCREEN_ < 768 || S < 768){
			media = "mobile";
		}
		
		if(media != "mobile"){
			if($(".video-slider").children().length > 0){
				video_slider = $(".video-slider").bxSlider({ auto: false, speed: 1000, controls: true, pager: true, pagerCustom: "#bx-pager-vdo", nextSelector: '.video-next', nextText: '>>', infiniteLoop: false, adaptiveHeight: false, onSliderLoad: function(){ if(video_lenght < 2){ $("#bx-pager-vdo").css("display", "none"); } } });
			}
			if($(".news-slider").children().length > 0){
				news_slider = $(".news-slider").bxSlider({ auto: false, speed: 1000, controls: true, pager: true, pagerCustom: "#bx-pager-news", nextSelector: '.news-next', nextText: '>>', infiniteLoop: false, adaptiveHeight: true, onSliderLoad: function(){ if(news_lenght < 2){ $("#bx-pager-news").css("display", "none"); } } });
			}
		}
		if(media == "mobile"){
			if($(".video-slider-mobile").children().length > 0){
				video_slider_mobile = $(".video-slider-mobile").bxSlider({ auto: false, speed: 1000, minSlides: 2, maxSlides: 2, slideWidth: 400, slideMargin: 15, controls: true, pager: true, pagerCustom: "#vdo-pager-mobile", nextSelector: '.video-next', nextText: '>>', moveSlides: 1, infiniteLoop: (video_mobile_lenght < 3) ? false : true, onSliderLoad: function(){ if(video_mobile_lenght < 3){ $("#vdo-pager-mobile").css("display", "none"); } } });
			}
			if($(".news-slider-mobile").children().length > 0){
				video_slider_mobile = $(".news-slider-mobile").bxSlider({ auto: false, speed: 1000, controls: true, pager: true, pagerCustom: "#news-pager-mobile", nextSelector: '.news-next', nextText: '>>', moveSlides: 1, infiniteLoop: (news_mobile_lenght < 2) ? false : true, onSliderLoad: function(){ if(news_mobile_lenght < 2){ $("#news-pager-mobile").css("display", "none"); } } });
			}
		}
		
	});
});